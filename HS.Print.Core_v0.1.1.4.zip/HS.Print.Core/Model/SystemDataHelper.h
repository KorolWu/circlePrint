#pragma once

#include "../Common.h"
#include "../Ink/AirInkSysClient.h"
#include "../Print/HS/PrinterBoard.h"
#include "../Worker/SpittingHelper.h"

class SystemDataHelper
{
private:
	//��ӡϵͳ������Ϣ
	PrintCfg m_cfg;
	PHType m_phType;

	AirInkSysClient * m_airInkSysClient;
	PrinterBoard * m_printerBoard;

	SpittingHelper * m_spitHlp;

	static SystemDataHelper * s_sysDataHelper;

public:
	SystemDataHelper();
	~SystemDataHelper();

public:
	bool OnConfigOK();

	//��ȫ���������ʱ����
	static bool OnAllConfigOK();
	//���˳�ʱʹ��
	static void DeleteInstance();

	static AirInkSysClient & GetAirInkSysClient()
	{
		return *s_sysDataHelper->m_airInkSysClient;
	}

	static PrinterBoard & GetPrinterBoard()
	{
		return *s_sysDataHelper->m_printerBoard;
	}

	static SpittingHelper & GetSpittingHelper()
	{
		return *s_sysDataHelper->m_spitHlp;
	}


	static void UpdatePrintCfg(PrintCfg * cfg);
	static const PrintCfg & GetPrintCfg();

	static void UpdatePHType(PHType type);
	static PHType GetPHType();

};

