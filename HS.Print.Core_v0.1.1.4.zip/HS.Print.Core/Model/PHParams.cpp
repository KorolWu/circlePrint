#include "PHParams.h"



int PHParams::GetPHBriefInfo(PHType type, float *npi, int *needImgbit)
{
	switch (type)
	{
		//SE128,128�ף�50NPI
	case PHTSE128:
	default:
	{
		*needImgbit = 1;
		*npi = 50;
		return 128;
	}
	//QS256,256�ף�100NPI
	case PHTQS256:
	{
		*needImgbit = 1;
		*npi = 100;
		return 256;
	}
	//����,16�ף�100NPI
	case PHDMC116:
	{
		*needImgbit = 1;
		*npi = 100;
		return 16;
	}
	}
}
