#include "../stdafx.h"
#include "SystemDataHelper.h"

SystemDataHelper * SystemDataHelper::s_sysDataHelper = new SystemDataHelper();

SystemDataHelper::SystemDataHelper()
	: m_airInkSysClient(nullptr)
	, m_printerBoard(nullptr)
	, m_phType(PHUnknown)
	, m_spitHlp(nullptr)
{
	m_cfg.EncoderRes = 0.5;
	m_cfg.RequiredDPI = 300;
}


SystemDataHelper::~SystemDataHelper()
{
	delete m_spitHlp; m_spitHlp = nullptr;
	delete m_airInkSysClient;  m_airInkSysClient = nullptr;
	delete m_printerBoard;  m_printerBoard = nullptr;
}

bool SystemDataHelper::OnConfigOK()
{
	m_airInkSysClient = new AirInkSysClient();
	m_printerBoard = new PrinterBoard();

	if (m_airInkSysClient == nullptr || m_printerBoard == nullptr)
		return false;

	m_spitHlp = new SpittingHelper(*m_printerBoard);
	if (m_spitHlp == nullptr)
		return false;

	return true;
}

bool SystemDataHelper::OnAllConfigOK()
{
	return s_sysDataHelper->OnConfigOK();
}

void SystemDataHelper::DeleteInstance()
{
	delete SystemDataHelper::s_sysDataHelper;
}

void SystemDataHelper::UpdatePrintCfg(PrintCfg * cfg)
{
	//ֱ��ֵ����
	s_sysDataHelper->m_cfg = *cfg;
}

const PrintCfg & SystemDataHelper::GetPrintCfg()
{
	return s_sysDataHelper->m_cfg;
}

void SystemDataHelper::UpdatePHType(PHType type)
{
	s_sysDataHelper->m_phType = type;
}

PHType SystemDataHelper::GetPHType()
{
	return s_sysDataHelper->m_phType;
}
