
#include "../../stdafx.h"
#include <Winsock2.h>
#include "PbCmd.h"
#include "PrinterBoard.h"
#include "../../Utils/Tools/Mutex.h"
#include "../../ErrMacro.h"

#define MAXMTU 1460 //��Ҫ����MTU��С

#define m_socket (*(SOCKET*)m_sockHandle)
#define m_mutex ((Utils::Tools::Mutex*)m_mutexHanle)

using namespace std;

static void usDelay(UINT us)
{
	LARGE_INTEGER litmp;
	LONGLONG QPart1, QPart2;
	double dfMinus, dfFreq, dfTim;
	dfTim = 0.0;
	QueryPerformanceFrequency(&litmp);
	dfFreq = (double)litmp.QuadPart;// ��ü�������ʱ��Ƶ��
	QueryPerformanceCounter(&litmp);
	QPart1 = litmp.QuadPart;// ��ó�ʼֵ

	while (dfTim < us)
	{
		QueryPerformanceCounter(&litmp);
		QPart2 = litmp.QuadPart;//�����ֵֹ
		dfMinus = (double)(QPart2 - QPart1);
		dfTim = dfMinus / dfFreq;// ��ö�Ӧ��ʱ��ֵ����λΪ��
		dfTim *= 1000000;
	}
}

PrinterBoard::PrinterBoard()
	: m_sockHandle(new SOCKET)
	, m_mutexHanle(new Utils::Tools::Mutex())
	, m_sendTimeout(300)//ms
	, m_recvTimeout(300)
	, m_connTimeout(2)//s
	, m_isOpen(false)
{
	m_socket = INVALID_SOCKET;
}

PrinterBoard::~PrinterBoard()
{
	VacummControl(0);
	Disconnect();

	delete ((SOCKET*)m_sockHandle); m_sockHandle = nullptr;
	delete m_mutex; m_mutexHanle = nullptr;
}

int PrinterBoard::InitConnect()
{
	int rcvbuf;
	int rcvbufsize = sizeof(int);

	m_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_socket == INVALID_SOCKET)
		return WSAGetLastError();

	//���÷��ͳ�ֵ
	if (::setsockopt(m_socket, SOL_SOCKET, SO_SNDTIMEO, (char*)&m_sendTimeout, sizeof(m_sendTimeout)) == SOCKET_ERROR)
		return WSAGetLastError();

	if (::setsockopt(m_socket, SOL_SOCKET, SO_RCVTIMEO, (char*)&m_recvTimeout, sizeof(m_recvTimeout)) == SOCKET_ERROR)
		return WSAGetLastError();

	if (getsockopt(m_socket, SOL_SOCKET, SO_RCVBUF, (char*)&rcvbuf, &rcvbufsize) != SOCKET_ERROR)
	{
		if (rcvbuf < 65536)
			rcvbuf = 65536;
		setsockopt(m_socket, SOL_SOCKET, SO_RCVBUF, (char*)&rcvbuf, rcvbufsize);
	}

	if (getsockopt(m_socket, SOL_SOCKET, SO_SNDBUF, (char*)&rcvbuf, &rcvbufsize) != SOCKET_ERROR)
	{
		if (rcvbuf < 65536)
			rcvbuf = 65536;
		setsockopt(m_socket, SOL_SOCKET, SO_SNDBUF, (char*)&rcvbuf, rcvbufsize);
	}

	return ERR_PB_NOERR;
}

int PrinterBoard::CommonCmd(const byte * cmd, int sndLen, byte * ack, int ackLen)
{
	int ret;

	ret = SendAndRecv(cmd, sndLen, ack, ackLen);

	if (ret != ERR_PB_NOERR)
		goto labErr;

	if (::memcmp(cmd, ack, ackLen) != 0)
	{
		ret = ERR_PB_CMDACKMTERR;
		goto labErr;
	}

	return ERR_PB_NOERR;

labErr:
	return ret;
}

int PrinterBoard::Connect(uint32 IPAddress, uint16 PortNum)
{
	int errCode;
	fd_set rdSet;
	ULONG ioMode = 1;//1:��������0������
	struct timeval timeout;

	m_mutex->Lock();

	m_isOpen = false;

	//���ɵ��ͷ�
	if (m_socket != INVALID_SOCKET)
		Disconnect();

	if (0 != (errCode = InitConnect()))
	{
		m_mutex->UnLock();
		return errCode;
	}

	//����Ϊ��������ʽ
	errCode = ioctlsocket(m_socket, FIONBIO, (unsigned long*)&ioMode);
	if (errCode == SOCKET_ERROR)
	{
		m_mutex->UnLock();
		return WSAGetLastError();
	}

	SOCKADDR_IN addr;
	memset(&addr, 0, sizeof(SOCKADDR_IN));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(PortNum);
	addr.sin_addr.S_un.S_addr = htonl(IPAddress);

	errCode = connect(m_socket, (const struct sockaddr*)&addr, sizeof(addr));

	//������ʱ����SOCKET_ERROR
	//if (ret == SOCKET_ERROR)
	//	return false;

	FD_ZERO(&rdSet);
	FD_SET(m_socket, &rdSet);
	timeout.tv_sec = m_connTimeout;
	timeout.tv_usec = 0;
	errCode = select(0, 0, &rdSet, 0, &timeout);
	if (errCode <= 0)
	{
		Disconnect();
		m_mutex->UnLock();
		return ERR_PB_TIMEOUT;//���ӳ�ʱ
	}

	//���û�����ģʽ
	ioMode = 0;
	errCode = ioctlsocket(m_socket, FIONBIO, (unsigned long*)&ioMode);
	if (errCode == SOCKET_ERROR)
	{
		Disconnect();
		m_mutex->UnLock();
		return WSAGetLastError();
	}

	//��ս��ջ�����
	ClearBuff();
	m_isOpen = true;//���ӳɹ�

	m_mutex->UnLock();

	return ERR_PB_NOERR;
}

void PrinterBoard::ClearBuff()
{
	if (!m_isOpen)
		return;

	// ����select��������
	timeval tmOut;
	tmOut.tv_sec = 0;
	tmOut.tv_usec = 1000;

	fd_set readFds;

	int res;
	char recv_data[1024];
	::memset(recv_data, 0, sizeof(recv_data));

	while (true)
	{
		FD_ZERO(&readFds);
		FD_SET(m_socket, &readFds);
		res = ::select(1, &readFds, NULL, NULL, &tmOut);

		if (res == 1)
		{
			res = recv(m_socket, recv_data, 1024, 0);  //�������ݶ�ȡ
			//0 �Ͽ������ˣ�SOCKET_ERROR ������
			if (res == 0 || res == SOCKET_ERROR)
				return;
		}
		else if (res == SOCKET_ERROR)//����
			return;
		else//0
			return;  //���ݶ�ȡ��ϣ���������ճɹ�
	}
}

int PrinterBoard::SendOnePassData(const byte* sndBuff, uint32 sizeBytes, bool checkErr)
{
	int errCode;
	//��ǰҪ���͵��ֽ���
	int curLen = 0;
	//�ѷ����ֽ���
	uint32 sndLen = 0;
	byte ack[ACKLEN] = { 0 };
	static const byte recComf[ACKLEN] = { CMD_HEAD, 0x88 ,00, 00, 00, 00 ,00, CMD_TAIL };

	m_mutex->Lock();

	//����"дRAM����"
	if ((errCode = StartWriteRam()) != ERR_PB_NOERR)
		goto labErr;

	while (true)
	{
		//���㱾�η��͵�������
		if ((sizeBytes - sndLen) >= MAXMTU)//Ӳ��Ҫ��һ�β��ó���2K�����԰������MTU��С����
			curLen = MAXMTU;
		else
			curLen = sizeBytes - sndLen;//ʣ��

		if (curLen <= 0)
			break;

		//����
		::memset(ack, 0, ACKLEN);
		errCode = SendAndRecv((sndBuff + sndLen), curLen, ack, ACKLEN);

		if (errCode != ERR_PB_NOERR)
			goto labErr;

		//��ȡ�������Ƚ�
		if (::memcmp(recComf, ack, ACKLEN) != 0)
		{
			errCode = ERR_PB_CMDACKMTERR;
			goto labErr;
		}

		sndLen += curLen;
		//�Ƿ�ﵽָ������
		if (sndLen >= sizeBytes)
			break;
	}

	//�ײ����ż���ᷢ������ack������Ҫ�����
	Sleep(2);
	//��ս��ջ�����
	ClearBuff();

	//����"ֹͣдRAM����"
	if ((errCode = StopWriteRam()) != ERR_PB_NOERR)
		goto labErr;


	//У��
	if (checkErr)
	{
		byte* recv = new byte[sizeBytes + INVALDHEADLEN];//����ͷ����3����Ч�ַ�
		::memset(recv, 0, sizeBytes + INVALDHEADLEN);

		//��ȡ���ص�ͼ��
		errCode = ReceivePassData(recv, sizeBytes + INVALDHEADLEN);
		if (errCode != ERR_PB_NOERR)
		{
			delete[]recv;
			goto labErr;
		}

		//�Ƚ��Ƿ�һ��
		if (::memcmp(sndBuff, recv + INVALDHEADLEN, sizeBytes) != 0)
		{
			delete[]recv;
			errCode = ERR_PB_RAWPASSERR;
			goto labErr;
		}

		delete[]recv;
	}

	m_mutex->UnLock();
	return ERR_PB_NOERR;

labErr:
	m_mutex->UnLock();
	return errCode;
}

int PrinterBoard::ReceivePassData(byte* recvBuff, uint32 recvSize)
{
	int errCode;
	byte* ack = recvBuff;
	uint32 fromAddr = 0;
	int offset = 0;

	byte cmd[CMDLEN] = { 0 };
	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_READ_RAM;
	cmd[7] = CMD_TAIL;

	int sndNum = recvSize / READRAMSIZE + ((recvSize % READRAMSIZE != 0) ? 1 : 0);

	//ÿ����һ�λ�ȡ2048���ֽ�
	for (int i = 0; i < sndNum; i++)
	{
		//�л���ַ
		cmd[4] = (byte)((fromAddr >> 16) & 0xff);
		cmd[5] = (byte)((fromAddr >> 8) & 0xff);
		cmd[6] = (byte)(fromAddr & 0xff);

		//����
		if ((i + 1) == sndNum &&//���һ��
			(recvSize % READRAMSIZE != 0))//�����ʣ��
		{
			//���һ�εĻ���û��2K����������ʱ�����ȡ��Ȼ����
			byte tmp[READRAMSIZE] = { 0 };
			errCode = SendAndRecv(cmd, CMDLEN, tmp, READRAMSIZE);
			//�����ݸ��ƽ�buf��
			::memcpy(ack + offset, tmp, recvSize - offset);
		}
		else
			errCode = SendAndRecv(cmd, CMDLEN, ack + offset, READRAMSIZE);

		if (errCode != ERR_PB_NOERR)
			return errCode;

		fromAddr += 1024;
		offset += READRAMSIZE;
	}

	return ERR_PB_NOERR;
}


void PrinterBoard::Disconnect()
{
	m_mutex->Lock();

	m_isOpen = false;
	if (m_socket != INVALID_SOCKET)
	{
		//linux: SHUT_RDWR
		::shutdown(m_socket, SD_BOTH);
		::closesocket(m_socket);
	}

	m_socket = INVALID_SOCKET;

	m_mutex->UnLock();
}


void PrinterBoard::SetSendTimeout(int timeout)
{
	if (timeout <= 0)
		m_sendTimeout = 300;
	else
		m_sendTimeout = timeout;
}
void PrinterBoard::SetRecvTimeout(int timeout)
{
	if (timeout <= 0)
		m_recvTimeout = 300;
	else
		m_recvTimeout = timeout;
}
void PrinterBoard::SetConnectTimeout(int timeout)
{
	if (timeout <= 0)
		m_connTimeout = 2;
	else
		m_connTimeout = timeout;
}


//������������Ƚ��䷵��ֵ�����ڼ�������Ƿ�ͨ����
int PrinterBoard::CheckConnected()
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = 0x04;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

//����LED
int PrinterBoard::TurnOnPositionLED(bool bTurnOn)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_LED_CTL;
	cmd[7] = CMD_TAIL;
	cmd[6] = bTurnOn ? SWITCH_ON : SWITCH_OFF;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}


int PrinterBoard::SendAndRecv(const byte* sndData, int dataBytes, byte * ack, int ackLen)
{
	if (!m_isOpen)
		return ERR_PB_DISCON;

	if (dataBytes == 0 || ackLen == 0)
		return ERR_PB_INPUTERR;

	int res, errCode;
	//�ѷ��ͻ���յ�����
	int sndLen = 0;

	m_mutex->Lock();

	//���ж�һ�Σ���ֹ�˿ڹر��˶���������
	if (!m_isOpen)
	{
		res = ERR_PB_DISCON;
		goto labErr;
	}

	//�����������
	ClearBuff();

	//д��
	while (true)
	{
		res = ::send(m_socket, (char*)(sndData + sndLen), dataBytes - sndLen, 0);
		if (res < 0)
		{
			errCode = WSAGetLastError();
			goto labErr;
		}
		else if (res == 0)
		{
			errCode = ERR_PB_DISCON;
			goto labErr;
		}
		else// if (res > 0)
		{
			sndLen += res;
			//�Ƿ�ﵽָ������
			if (sndLen >= dataBytes)
				break;
		}
	}

	//����������
	sndLen = 0;

	while (true)
	{
		res = ::recv(m_socket, (char*)(ack + sndLen), ackLen - sndLen, 0);

		if (res < 0)
		{
			errCode = WSAGetLastError();
			goto labErr;
		}
		else if (res == 0)
		{
			errCode = ERR_PB_DISCON;
			goto labErr;
		}
		else// if (res > 0)
		{
			sndLen += res;
			//�Ƿ�ﵽָ������
			if (sndLen >= ackLen)
				break;
		}
	}

	m_mutex->UnLock();

	return ERROR_SUCCESS;

labErr:
	m_mutex->UnLock();
	return errCode;
}


int PrinterBoard::StartPrint()
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_START_PRINT;
	cmd[5] = 0x55;
	cmd[6] = 0x55;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}


int PrinterBoard::StopPrint()
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_STOP_PRINT;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::PausePrint()
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_PAUSE_PRINT;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::GetStatus(char status[10])
{
	byte cmd[CMDLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_GET_STAUS;

	return SendAndRecv(cmd, CMDLEN, (byte*)status, 10);
}

int PrinterBoard::EncoderReset()
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_ENCODER_RESET;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::GasControl(bool bTurnOn)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_GAS_ALLCTL;
	cmd[6] = bTurnOn ? SWITCH_ON : SWITCH_OFF;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::VacummControl(bool bTurnOn)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_GAS_VCMMCTL;
	cmd[6] = bTurnOn ? SWITCH_ON : SWITCH_OFF;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::HeadClear(bool bTurnOn)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_HEAD_CLEAR;
	cmd[6] = bTurnOn ? SWITCH_ON : SWITCH_OFF;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::InkPumpControl(bool bTurnOn, byte inkNo)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = inkNo == 1 ? CMD_INK_CTL : CMD_INK_CTL2;
	cmd[6] = bTurnOn ? SWITCH_ON : SWITCH_OFF;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}


int PrinterBoard::StartReadRam(uint32 fromAddr)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_READ_RAM;
	cmd[7] = CMD_TAIL;

	cmd[4] = (byte)((fromAddr >> 16) & 0xff);
	cmd[5] = (byte)((fromAddr >> 8) & 0xff);
	cmd[6] = (byte)(fromAddr & 0xff);

	//��ָ�����ɺ�ֱ�Ӷ�ȡ����


	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

//��ʼдRAM����
int PrinterBoard::StartWriteRam()
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_START_WRITE_RAM;
	cmd[7] = CMD_TAIL;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}



int PrinterBoard::StopWriteRam()
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_STOP_WRITE_RAM;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}



//���õ�Դͨ����ַ
int PrinterBoard::SetChannelAddr()
{
	char Param[8];
	int ret;
	memset(Param, 0x00, 8);
	Param[0] = 'M';
	Param[1] = 'E';
	Param[2] = 0x00;
	Param[3] = 0x03;
	Param[4] = 0x0a;
	Param[5] = 0x10;
	Param[6] = 0x01;
	for (int i = 0; i < 7; i++)
		Param[7] += Param[i];

	for (int j = 0; j < 8; j++)
	{
		ret = SetPowerParam(Param[j]);
		if (ret != ERR_PB_NOERR)
			return ret;
	}
	Param[5] = 0x20;
	Param[6] = 0x02;
	for (int i = 0; i < 7; i++)
		Param[7] += Param[i];
	for (int j = 0; j < 8; j++)
	{
		ret = SetPowerParam(Param[j]);
		if (ret != ERR_PB_NOERR)
			return ret;
	}
	return ERR_PB_NOERR;
}

int PrinterBoard::PowerSwitch(bool bTurnOn, byte nChannelAddr)
{
	if (nChannelAddr != 0x10 && nChannelAddr != 0x20 && nChannelAddr != 30 && nChannelAddr != 40)
		return ERR_PB_INPUTERR;
	byte Param[7];
	int ret;
	memset(Param, 0x00, 7);
	Param[0] = 'M';
	Param[1] = 'E';
	Param[2] = nChannelAddr;
	Param[3] = 0x01;
	Param[4] = 0x01;
	if (bTurnOn)
		Param[5] = 0x01;
	else
		Param[5] = 0x00;

	for (int i = 0; i < 6; i++)
		Param[6] += Param[i];

	m_mutex->Lock();

	for (int j = 0; j < 7; j++)
	{
		ret = SetPowerParam(Param[j]);
		if (ret != ERR_PB_NOERR)
		{
			m_mutex->UnLock();
			return ret;
		}
	}

	m_mutex->UnLock();

	return ERR_PB_NOERR;
}

int PrinterBoard::SetPowerParam(byte param)//���͸�ѹ��Դ���Ӻ���
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_SET_VOL;
	cmd[6] = param;
	cmd[7] = CMD_TAIL;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

byte PrinterBoard::WaveFormFunc(byte nRise, byte nFall, byte nDue, byte nVol, float input)
{
	byte total = nRise + nFall + nDue;
	if (input < 0)
		return 0;
	float output;
	if (input <= nRise)
		output = (float)(nVol * 255 * input) / (180 * nRise);
	else if (input < (nRise + nDue))
		output = (float)((nVol * 255) / 180);
	else
		output = (float)((total - input) * 255 * nVol) / (180 * nFall);
	return (byte)output;
}

byte GetWFChn(WFChnAddr chnAddr, byte * addr)
{
	switch (chnAddr)
	{
	case WFChnAddr1:
		*addr = WAVEFORMCHN1;
		break;
	case WFChnAddr2:
		*addr = WAVEFORMCHN2;
		break;
	default:
		return ERR_PB_INPUTERR;
	}

	return ERR_PB_NOERR;
}

int PrinterBoard::SendWaveForm(byte nRise, byte nFall, byte nDue, byte nVol, WFChnAddr wfChnAddr)//���Ͳ����ļ�
{
	byte chnAddr;
	int ret = GetWFChn(wfChnAddr, &chnAddr);

	if (ERR_PB_NOERR != ret)
		return ret;

	float total = (float)((nRise + nDue + nFall)*8.25);
	byte sampleNum = (byte)total + 1;
	byte* WaveFormData = new byte[sampleNum];
	memset(WaveFormData, 0x00, sampleNum);
	for (int i = 0; i < sampleNum; i++)
	{
		float input = (float)(i / 8.25);
		WaveFormData[i] = WaveFormFunc(nRise, nFall, nDue, nVol, input);
	}
	byte SendData[256] = { 0 };
	memcpy(SendData, WaveFormData, sampleNum);
	byte startAddr = 0x00;

	char tempData[16];

	m_mutex->Lock();

	for (int j = 0; j < 16; j++)
	{
		memcpy(tempData, SendData + startAddr, 16);
		ret = SendWaveFormCmd(chnAddr, startAddr, (byte*)tempData, 16);

		if (ret != ERR_PB_NOERR)
		{
			m_mutex->UnLock();
			delete[] WaveFormData;
			return ret;
		}
		startAddr += 16;
		Sleep(50);//һ��Ҫ����ʱ�������ζ���
	}

	m_mutex->UnLock();

	delete[] WaveFormData;

	return ret;
}

int PrinterBoard::SendWaveFormCmd(byte nChannelAddr, byte nStartAddr, byte* data, byte nlength)//����һ�β������ݺ���
{
	if (nlength > 0 && data == nullptr)
		return ERR_PB_INPUTERR;

	int ret = 0;
	byte len = 6 + 1 + nlength;
	byte* cmd = new byte[len];
	memset(cmd, 0x00, len);

	cmd[0] = 'M';
	cmd[1] = 'E';
	cmd[2] = nChannelAddr;
	cmd[3] = nlength + 2;
	cmd[4] = 0x04;
	cmd[5] = nStartAddr;

	memcpy(cmd + 6, data, nlength);

	for (int i = 0; i < len - 1; i++)
		cmd[len - 1] += cmd[i];//���һλΪУ��ͣ�


	//һ��������
	for (int j = 0; j < len; j++)
	{
		if ((ret = SetPowerParam(cmd[j])) != ERR_PB_NOERR)
		{
			delete[]cmd;
			return ret;
		}

		usDelay(500);
	}

	delete[]cmd;
	return ERR_PB_NOERR;
}


int PrinterBoard::TuneLEDLum(uint32 lum)
{
	//�ع�ʱ��
	//uint32 time = lum * 1000;
	//lum = time / 20;

	lum = lum * 50;

	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_LED_LUM;

	cmd[3] = (lum >> 24) & 0xff;
	cmd[4] = (lum >> 16) & 0xff;
	cmd[5] = (lum >> 8) & 0xff;
	cmd[6] = (lum & 0xff);

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::SetFireFrequency(uint32 uFireFreq)
{
	if (uFireFreq > 20000 || uFireFreq == 0)
		return ERR_PB_INPUTERR;

	uint32 data = FREQTOTAL / uFireFreq;

	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_NOZZLE_FREQ;


	cmd[3] = (data >> 24) & 0xff;
	cmd[4] = (data >> 16) & 0xff;
	cmd[5] = (data >> 8) & 0xff;
	cmd[6] = (data & 0xff);

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);

}

int PrinterBoard::NozzleTestControl(bool bTest)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[7] = CMD_TAIL;
	cmd[1] = CMD_TEST_NOZZLE;
	cmd[6] = bTest ? 1 : 0;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int PrinterBoard::SetNozzleData(uint32* data, int num)
{
	if (num > 16)
		return ERR_PB_INPUTERR;

	int ret;

	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN];

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_NOZZLE_DATA;
	cmd[7] = CMD_TAIL;

	m_mutex->Lock();

	for (int i = 0; i < num; i++)
	{
		memset(ack, 0x00, ACKLEN);

		cmd[2] = byte(i + 1);

		cmd[3] = (data[i] >> 24) & 0xff;
		cmd[4] = (data[i] >> 16) & 0xff;
		cmd[5] = (data[i] >> 8) & 0xff;
		cmd[6] = (data[i] & 0xff);

		if ((ret = CommonCmd(cmd, CMDLEN, ack, ACKLEN)) != ERR_PB_NOERR)
		{
			m_mutex->UnLock();
			return ret;
		}
	}

	m_mutex->UnLock();
	return ERR_PB_NOERR;
}

int PrinterBoard::SetNozzleData128(uint32 data[4])
{
	return SetNozzleData(data, 4);
}

int PrinterBoard::SetNozzleData512(uint32 data[16])
{
	return SetNozzleData(data, 16);
}

//0-5000 ---> 0-500MA
int PrinterBoard::TuneLEDCurrent(uint16 wValue)   //LED����
{
	if (wValue > 5000)
		return ERR_PB_INPUTERR;

	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_LED_CURRENT;  //0x1c
	cmd[5] = (wValue >> 8) & 0xff;
	cmd[6] = (wValue & 0xff);
	cmd[7] = CMD_TAIL;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}


int PrinterBoard::TuneDelaySpeed(byte speed)    //����ͷ�ٶ�
{
	if (speed > 10)
		return ERR_PB_INPUTERR;

	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_DELAY_SPEED;   //0x1e
	cmd[7] = CMD_TAIL;
	cmd[6] = speed;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}


int PrinterBoard::SlowMode(bool bOn)      //����ͷ����
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_SLOW_MODE; //0x1d
	cmd[6] = bOn ? 1 : 0;
	cmd[7] = CMD_TAIL;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}


int PrinterBoard::RepeatPrintCtl(bool bOn)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_REPEAT_CTL;
	cmd[6] = bOn ? 1 : 0;
	cmd[7] = CMD_TAIL;

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}
int PrinterBoard::SetRepeatTimes(int times)
{
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = CMD_REPEAT_TIMES;
	cmd[7] = CMD_TAIL;

	//cmd[2]=i+1;
	cmd[3] = (times >> 24) & 0xff;
	cmd[4] = (times >> 16) & 0xff;
	cmd[5] = (times >> 8) & 0xff;
	cmd[6] = (times & 0xff);

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}


int PrinterBoard::SetPrintHeadType(PHType type)
{
	//type :1 - ����������128��ͷ 2- ����256
	byte cmd[CMDLEN] = { 0 };
	byte ack[ACKLEN] = { 0 };

	cmd[0] = CMD_HEAD;
	cmd[1] = 0x21;
	cmd[7] = CMD_TAIL;

	switch (type)
	{
	case PHTSE128:
	case PHDMC116:
		cmd[6] = 0x01;
		break;
	case PHTQS256:	//QS256
		cmd[6] = 0x02;
		break;
	default:
		return ERR_PB_INPUTERR;
	}

	return CommonCmd(cmd, CMDLEN, ack, ACKLEN);
}

int  PrinterBoard::PowerInit()
{
	byte Param[6] = { 0x4D ,0x45 ,0x00, 0x01, 0x0D ,0xA0 };
	int ret;

	m_mutex->Lock();

	for (int i = 0; i < 6; i++)
		if ((ret = SetPowerParam(Param[i])) != ERR_PB_NOERR)
			goto labErr;

	m_mutex->UnLock();

	return ERR_PB_NOERR;

labErr:
	m_mutex->UnLock();
	return ret;
}
