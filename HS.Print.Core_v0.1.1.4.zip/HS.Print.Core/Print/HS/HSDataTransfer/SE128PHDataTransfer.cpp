#include <cstring>
#include "../../../ErrMacro.h"
#include "SE128PHDataTransfer.h"


SE128PHDataTransfer::SE128PHDataTransfer(int port)
	: HSPHDataTransfer(PHTSE128, port, 128)
{
}

SE128PHDataTransfer::~SE128PHDataTransfer()
{
}

int SE128PHDataTransfer::GetBytesPosWhenPrint(int nozIndex, int *index)
{
	if (m_phPort == 0 || m_phPort == 1)
	{
		int startByte = 0;
		if (nozIndex % 2 == 0)//ż��
		{
			nozIndex = nozIndex >> 1;
			startByte = (m_phPort == 0 ? 63 : 31); 
		}
		else//����
		{
			nozIndex = (nozIndex - 1) >> 1;//������
			startByte = (m_phPort == 0 ? 63 : 31) - 8;//������ż����8���ֽ�λ
		}
		*index = nozIndex % 8;
		return	startByte - (nozIndex >> 3);//����8
	}

	return ERR_PB_UNSUPPORT;
}

int SE128PHDataTransfer::GetBytesPosWhenTest(int nozIndex, int *index)
{
	if (m_phPort == 0 || m_phPort == 1)
	{
		int startByte = 0;
		if (nozIndex % 2 == 0)//ż��
		{
			nozIndex = nozIndex >> 1;//������
			startByte = (m_phPort == 0 ? 0 : 32);
		}
		else//����
		{
			nozIndex = (nozIndex - 1) >> 1;
			startByte = (m_phPort == 0 ? 0 : 32) + 8;//������ż����8���ֽ�λ
		}
		*index = nozIndex % 8;
		return	startByte + (nozIndex >> 3);//����8
	}

	return ERR_PB_UNSUPPORT;
}
