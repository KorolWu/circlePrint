#include <cstdio>
#include <cstdarg>
#include <cstring>
#include "StringHelper.h"
#include "Encodor.h"

using namespace System::Text;

#define DEFAULTLEN 256



int StringHelper::IndexOf(const Char* path, Char value)
{
	size_t size = -1;

	if (path == nullptr || (size = Strlen(path)) == 0)
		return -1;


	for (int i = 0; i < size;i++)
	{
		if (path[i] == value)
			return i;
	}

	return -1;
}


int StringHelper::LastIndexOf(const Char* path, Char value)
{
	int startIndex = -1;

	if (path == nullptr || (startIndex = (int)Strlen(path)) == 0)
		return -1;

	while (--startIndex >= 0)
	{
		if (path[startIndex] == value)
			return startIndex;
	}
	return -1;
}


int StringHelper::Split(const String& input, Char separator, String*& arrOutput)
{
	if (input.length() <= 0)
	{
		arrOutput = nullptr;
		return 0;
	}

	int inum = 0;
	int startIndex = 0;
	int endIndex = -1;
	std::list<String> lst;

	while ((endIndex = (int)input.find(separator, startIndex)) >= 0)
	{
		if (startIndex <= endIndex)
		{
			lst.push_back(input.substr(startIndex, endIndex - startIndex));
			startIndex = endIndex + 1;
		}
		else
			break;
	}

	int size = (int)lst.size();
	if (size > 0)
	{
		//�������һ���ַ���
		if (startIndex <= (input.length() - 1))
		{
			lst.push_back(input.substr(startIndex, input.length() - startIndex));
			size++;
		}

		arrOutput = new String[size];
		int index = 0;

		for (std::list<String>::iterator val = lst.begin(); val != lst.end(); val++)
		{
			arrOutput[index++] = *val;
		}

		return size;
	}
	else
	{
		arrOutput = new String[1];
		arrOutput[0] = input;
		return 1;
	}
}

//ת����Сд
bool StringHelper::ToLower(const Char* src, Char* dest)
{
	if (src == nullptr || dest == nullptr)
		return false;

	Char dis = _T('a') - _T('A');

	dest[Strlen(src)] = _T('\0');

	do
	{
		*dest++ = *src + ((*src >= _T('A') && *src <= _T('Z')) ? dis : 0);

	} while (*(++src) != _T('\0'));

	return true;
}

bool StringHelper::ToUpper(const Char* src, Char* dest)
{
	if (src == nullptr || dest == nullptr)
		return false;

	Char dis = _T('a') - _T('A');

	dest[Strlen(src)] = _T('\0');

	do
	{
		*dest++ = *src - ((*src >= _T('a') && *src <= _T('z')) ? dis : 0);

	} while (*(++src) != _T('\0'));

	return true;
}

String StringHelper::ToLower(const String& str)
{
	if (str.size() == 0)
		return EMPTYSTRING;

	Char *arr = new Char[str.size() + 1];

	ToLower(str.c_str(), arr);

	String tmp(arr);

	delete[] arr;

	return tmp;
}

//ת����Сд
String StringHelper::ToUpper(const String& str)
{
	if (str.size() == 0)
		return EMPTYSTRING;

	Char *arr = new Char[str.size() + 1];

	ToUpper(str.c_str(), arr);

	String tmp(arr);

	delete[] arr;

	return tmp;
}


int StringHelper::Format(const char * format, std::string* result, va_list lst)
{
	//255Ϊ�����ӵ��ַ�������ֹ�����������ݳ��Ȳ�����
	size_t maxlen = strlen(format) + 1;

	//����С����һ��ʱ
	if (maxlen <= DEFAULTLEN / 2)
		maxlen = DEFAULTLEN;
	else
		maxlen += DEFAULTLEN;

	char * newChar = new char[maxlen];
	//�ڴ����ʧ��
	if (newChar == nullptr)
		return -2;

	//_TRUNCATE�᷵�ؽضϺ���ַ���
	int res = vsnprintf_s(newChar, maxlen, _TRUNCATE, format, lst);

	//������Ȳ���
	if (res == -1)//һ�㲻�����maxlen
	{
		//��������һ��������
		maxlen *= 2;
		delete[] newChar;
		newChar = new char[maxlen];
		//�ڴ����ʧ��
		if (newChar == nullptr)
			return -2;

		res = vsnprintf_s(newChar, maxlen, _TRUNCATE, format, lst);
	}

	va_end(lst);

	*result = newChar;
	delete[] newChar;

	return res;
}

int StringHelper::Format(const wchar_t * format, std::wstring* result, va_list lst)
{
	//255Ϊ�����ӵ��ַ�������ֹ�����������ݳ��Ȳ�����
	size_t maxlen = wcslen(format) + 1;

	//����С����һ��ʱ
	if (maxlen <= DEFAULTLEN / 2)
		maxlen = DEFAULTLEN;
	else
		maxlen += DEFAULTLEN;

	wchar_t * newChar = new wchar_t[maxlen];
	//�ڴ����ʧ��
	if (newChar == nullptr)
		return -2;

	//_TRUNCATE�᷵�ؽضϺ���ַ���
	int res = _vsnwprintf_s(newChar, maxlen, _TRUNCATE, format, lst);

	//������Ȳ���
	if (res == -1)//һ�㲻�����maxlen
	{
		//��������һ��������
		maxlen *= 2;
		delete[] newChar;
		newChar = new wchar_t[maxlen];
		//�ڴ����ʧ��
		if (newChar == nullptr)
			return -2;

		res = _vsnwprintf_s(newChar, maxlen, _TRUNCATE, format, lst);
	}

	va_end(lst);

	*result = newChar;
	delete[] newChar;

	return res;
}

int StringHelper::Format(const char * format, std::string* result, ...)
{
	va_list lst;
	va_start(lst, result);
	return Format(format, result, lst);
}


int StringHelper::Format(std::string *format, ...)
{
	va_list lst;
	va_start(lst, format);
	return Format(format->c_str(), format, lst);
}

int  StringHelper::Format(const wchar_t * format, std::wstring* result, ...)
{
	va_list lst;
	va_start(lst, result);
	return Format(format, result, lst);
}


int StringHelper::Format(std::wstring *format, ...)
{
	va_list lst;
	va_start(lst, format);
	return Format(format->c_str(), format, lst);
}


#undef DEFAULTLEN