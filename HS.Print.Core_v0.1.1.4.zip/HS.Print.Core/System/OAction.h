#pragma once
#include "Object.h"

typedef void (System::Object::*OAction)(void *);
