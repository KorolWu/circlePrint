#include "File.h"

#include <stdio.h>

#if  defined( WIN32)|| defined(_WIN32)

#include <direct.h>  
#include <io.h>
#include<wchar.h>

#if defined(UNICODE) || defined(_UNICODE) 

#define ACCESS  _waccess
#define RM  _wremove
#else
#define ACCESS  _access
#define RM remove
#endif //UNICODE

#else

//ʹ��rmdir����ʱ��Ŀ¼����Ϊ�գ��������ʧ��
#define RM remove 
#define ACCESS access

#endif

using namespace System::IO;

File::File()
{
}


File::~File()
{
}


bool File::Delete(const String& path)
{
#if  defined( WIN32)|| defined(_WIN32)
	return 0 == RM(path.c_str());
#else
	return 0 == RM(NEWSTR2CHARSTR(path).c_str());
#endif
}

bool File::Exists(const String& path)
{
#if  defined( WIN32)|| defined(_WIN32)
	return	ACCESS(path.c_str(), 00) == 0;
#else
	return ACCESS(NEWSTR2CHARSTR(Path::GetFormatDirectory(path)).c_str(), 00) != -1;
#endif

}
