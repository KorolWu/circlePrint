#pragma once
#include "BasicType.h"

namespace System
{
	class Object
	{
	public:
		Object() {};
		virtual ~Object() {};
	};
}
