#ifndef _BASICTYPE_H_
#define  _BASICTYPE_H_

#pragma once

#ifdef __cplusplus
	#include "String.h"
#endif

typedef  char int8;
typedef  char sbyte;

typedef  short int16;

typedef  int int32;

typedef  long long int64;
typedef  long long longlong;

typedef unsigned char uint8;
typedef unsigned char byte;
typedef unsigned char uchar;

typedef unsigned short ushort;
typedef unsigned short uint16;

typedef unsigned int uint32;
typedef unsigned int uint;

typedef unsigned long long uint64;
typedef unsigned long long ulonglong;


#endif //_BASICTYPE_H_