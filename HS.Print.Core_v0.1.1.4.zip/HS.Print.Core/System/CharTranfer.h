#pragma once

#include <cstdlib>
#include <cmath> 

/****************************�ַ�ת����***************************/

#if defined(UNICODE) || defined(_UNICODE) 

#define  AtoI32(str) _wtoi(str)
#define  AtoI64(str) _wtoi64(str)

#define  AtoI32R(str,radix)  wcstol(str,nullptr,radix)
#define  AtoUI32R(str,radix)  wcstoul(str,nullptr,radix)

#define  AtoI64R(str,radix)  _wcstoi64(str,nullptr,radix)
#define  AtoUI64R(str,radix)  _wcstoui64(str,nullptr,radix)

#define  AtoF64(str) _wtof(str)

#else

#define  AtoI32(str) atoi(str)
#define  AtoI64(str) _atoi64(str)

#define  AtoI32R(str,radix)  strtol(str,nullptr,radix)
#define  AtoUI32R(str,radix)  strtoul(str,nullptr,radix)

#define  AtoI64R(str,radix)  _strtoi64(str,nullptr,radix)
#define  AtoUI64R(str,radix)  _strtoui64(str,nullptr,radix)

#define  AtoF64(str) atof(str)

#endif

