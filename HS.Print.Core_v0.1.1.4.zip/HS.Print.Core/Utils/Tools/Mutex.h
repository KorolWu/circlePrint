#pragma once


struct MutexAPI;

namespace Utils
{
	namespace Tools
	{
		class Mutex
		{
		private:
			struct MutexAPI * m_api;

		private:

			void Init();
			void Release();

		public:
			Mutex();
			virtual ~Mutex();
			void Lock();
			void UnLock();
		};
	}
}