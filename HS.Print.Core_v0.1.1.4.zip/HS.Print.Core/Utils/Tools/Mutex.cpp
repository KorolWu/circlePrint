
#include "Mutex.h"
#include <cstdio>


#if defined( _WIN32 ) || defined(_WINDOWS)
// Win Socket Header File(s)
#include <Windows.h>
#else
// POSIX Socket Header File(s)
#include <errno.h>
#include <pthread.h>
#endif

using namespace Utils::Tools;

struct MutexAPI
{

#if defined( _WIN32 ) || defined(_WINDOWS)
	CRITICAL_SECTION        m_Mutex;
#else
	pthread_mutexattr_t     m_Attr;
	pthread_mutex_t         m_Mutex;
#endif

};


Mutex::Mutex()
	:m_api(nullptr)
{
	Init();
}

Mutex::~Mutex()
{
	Release();
	delete m_api; m_api = nullptr;
}

void  Mutex::Init()
{
	m_api = new MutexAPI;

#if defined( _WIN32 ) || defined(_WINDOWS)
	InitializeCriticalSection(&m_api->m_Mutex);
#else
	int ret = 0;
	ret = pthread_mutexattr_settype(&m_api->m_Attr, PTHREAD_MUTEX_ERRORCHECK_NP);
	if (ret != 0)
	{
		printf("Mutex::Init() -- Mutex attribute not initialize!!\n");
		exit(0);
	}
	ret = pthread_mutex_init(&m_api->m_Mutex, &m_api->m_Attr);
	if (ret != 0)
	{
		printf("Mutex::Init() -- Mutex not initialize!!\n");
		exit(0);
	}
#endif

}

void Mutex::Lock()
{
#if defined( _WIN32 ) || defined(_WINDOWS)
	EnterCriticalSection(&m_api->m_Mutex);
#else
	pthread_mutex_lock(&m_api->m_Mutex);
#endif
}

void Mutex::UnLock()
{
#if defined( _WIN32 ) || defined(_WINDOWS)
	LeaveCriticalSection(&m_api->m_Mutex);
#else
	pthread_mutex_unlock(&m_api->m_Mutex);
#endif
}


void Mutex::Release()
{
#if defined( _WIN32 ) || defined(_WINDOWS)
	DeleteCriticalSection(&m_api->m_Mutex);
#else
	pthread_mutexattr_destroy(&m_api->m_Attr);
	pthread_mutex_destroy(&m_api->m_Mutex);
#endif
}