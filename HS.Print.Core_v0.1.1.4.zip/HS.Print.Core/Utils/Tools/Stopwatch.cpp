
#if defined( _WIN32 ) || defined(_WINDOWS)

#include <Windows.h>

static bool s_IsHighResolution;

static double s_tickFrequency;
static INT64 s_Frequency;

static const INT64 TicksPerMillisecond = 10000;
static const INT64 TicksPerSecond = 10000000;

#else
#include<sys/time.h>
#endif

#include "Stopwatch.h"


using namespace Utils::Tools;

Stopwatch::Stopwatch()
{
#if defined( _WIN32 ) || defined(_WINDOWS)
	static bool isFirst = true;
	//����ֻ����һ��
	if (isFirst)
	{
		if (!QueryPerformanceFrequency((LARGE_INTEGER *)(&s_Frequency)))
		{
			s_IsHighResolution = false;
			s_Frequency = 625000;
			s_tickFrequency = 1.0;
		}
		else
		{
			s_IsHighResolution = true;
			s_tickFrequency = TicksPerSecond / (double)s_Frequency;
		}
		isFirst = false;
	}
#endif

	Reset();
}
//����ν
Stopwatch::~Stopwatch()
{
	m_isRunning = false;
	m_elapsed = 0;
}


INT64 Stopwatch::GetTimestamp()
{
#if defined( _WIN32 ) || defined(_WINDOWS)
	//ʱ�����λΪticks
	if (s_IsHighResolution)
	{
		INT64 lCurrent = 0;
		QueryPerformanceCounter((LARGE_INTEGER *)(&lCurrent));
		return lCurrent;
	}
	else
	{
		ULONGLONG dateData = 0;
		GetSystemTimeAsFileTime((FILETIME*)(&dateData));

		ULONGLONG val = (ULONGLONG)((dateData + 0x701ce1722770000) | 0x4000000000000000);

		return ((INT64)val & 0x3fffffffffffffff);
	}

#else
	//ʱ�����λΪus
	timeval lcurrent;
	gettimeofday(&lcurrent, NULL);
	return (INT64)((INT64)res.tv_sec * 1000000 + res.tv_usec);

#endif

}

INT64 Stopwatch::ElapsedMicroseconds()
{
	INT64 rawElapsedTicks = this->m_elapsed;
	if (this->m_isRunning)
	{
		INT64 num2 = GetTimestamp() - m_startTimeStamp;
		rawElapsedTicks += num2;
	}

#if defined( _WIN32 ) || defined(_WINDOWS)
	return (INT64)((1000 * rawElapsedTicks * s_tickFrequency) / TicksPerMillisecond);
#else
	return rawElapsedTicks;
#endif
}


INT64 Stopwatch::ElapsedMilliseconds()
{
	return (INT64)(0.001 * ElapsedMicroseconds());
}


void Stopwatch::Reset()
{
	this->m_isRunning = false;

	this->m_elapsed = 0;
	this->m_startTimeStamp = 0;

}

void Stopwatch::Restart()
{
	this->m_isRunning = true;
	this->m_elapsed = 0;
	this->m_startTimeStamp = GetTimestamp();
}

void Stopwatch::Start()
{
	if (!this->m_isRunning)
	{
		this->m_startTimeStamp = GetTimestamp();
		this->m_isRunning = true;
	}
}


bool Stopwatch::IsRunning() const
{
	return this->m_isRunning;
}

void Stopwatch::Stop()
{
	if (this->m_isRunning)
	{
		INT64 num = GetTimestamp() - this->m_startTimeStamp;
		this->m_elapsed += num;
		if (this->m_elapsed < 0)
		{
			this->m_elapsed = 0;
		}
		this->m_isRunning = false;
	}
}




