
#include <Windows.h>
#include "Interlock.h"

Interlock::Interlock()
{
}


Interlock::~Interlock()
{
}

long Interlock::ExchangeAdd(long * volatile plAdd, long increment)
{
	return InterlockedExchangeAdd(plAdd, increment);
}

long long Interlock::ExchangeAdd64(long long * volatile plAdd, long long increment)
{
	return InterlockedExchangeAdd64(plAdd, increment);
}

long Interlock::ExchangeVal(long * volatile pldest, long lvalue)
{
	return InterlockedExchange(pldest, lvalue);
}

long long Interlock::ExchangeVal64(long long * volatile pldest, long long lvalue)
{
	return InterlockedExchange64(pldest, lvalue);
}

void* Interlock::ExchangePtr(void*volatile*  ppdest, void* pvValue)
{
	return InterlockedExchangePointer(ppdest, pvValue);
}

long Interlock::CompareExchange(long * volatile pldest, long lExchange, long lComparand)
{
	return InterlockedCompareExchange(pldest, lExchange, lComparand);
}

void* Interlock::CompareExchangePtr(void* volatile* ppdest, void* pvExchange, void * pvComparand)
{
	return InterlockedCompareExchangePointer(ppdest, pvExchange, pvComparand);
}
