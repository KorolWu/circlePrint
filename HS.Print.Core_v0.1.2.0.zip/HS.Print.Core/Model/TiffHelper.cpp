#include "../stdafx.h"

#include <tiffio.h>
#include <cmath>
#include "TiffHelper.h"

//#pragma comment(lib,"libtiff.lib")

#define BYTESPERROW(nw,nBpp) ((nw * nBpp) >> 3) + ((nw * nBpp) % 8 == 0 ? 0 : 1)  //ÿ���ֽ���

#if defined(UNICODE) || defined(_UNICODE) 
#define TIFFOpenEx TIFFOpenW
#else
#define TIFFOpenEx TIFFOpen
#endif

static void TIFFErrorHan(const char* pModule, const char* pFormat, va_list pArg)
{
	char szMsg[512];
	vsprintf_s(szMsg, pFormat, pArg);
	printf("tifferr-%s: %s\r\n", pModule, szMsg);
}

static void BindErrorHandler()
{
	static bool isSet = false;

	if (!isSet)
	{
		isSet = true;
		TIFFSetErrorHandler(TIFFErrorHan);
		TIFFSetWarningHandler(TIFFErrorHan);
	}
}

TiffHelper::TiffHelper(const System::Char * file)
	:m_rows(0), m_cols(0), m_rawData(nullptr), m_bitCount(8)
	, m_file(nullptr)
	, m_isWhiteSmall(false)
{
	BindErrorHandler();

	size_t len = Strlen(file) + 1;
	if (len > 1)
	{
		m_file = new System::Char[len];
		Strcpy_s(m_file, len, file);
	}
}


TiffHelper::~TiffHelper()
{
	if (m_rawData != nullptr)
	{
		delete[] m_rawData;
		m_rawData = nullptr;
	}

	if (m_file != nullptr)
	{
		delete[] m_file;
		m_file = nullptr;
	}

}

int TiffHelper::Height() const
{
	return m_rows;
}

int TiffHelper::Width() const
{
	return m_cols;
}

int TiffHelper::GetBitCount() const
{
	return m_bitCount;
}

int TiffHelper::BytesPerRow() const
{
	return BYTESPERROW(m_cols, m_bitCount);
}

unsigned char * TiffHelper::GetRawData()
{
	return m_rawData;
}


unsigned char * TiffHelper::RowAt(int rowIndex)
{
	if (m_rawData == nullptr)
		return nullptr;


	return (m_rawData + rowIndex * BytesPerRow());
}

bool TiffHelper::ReadFile()
{
	TIFF* pTif = TIFFOpenEx(m_file, "r");
	if (!pTif)
		return false;

	int  nret, npage;// , nrps;
	unsigned short nComp, nPho, nBps, nSpp;

	nret = TIFFGetField(pTif, TIFFTAG_IMAGEWIDTH, &m_cols);
	nret = TIFFGetField(pTif, TIFFTAG_IMAGELENGTH, &m_rows);

	nret = TIFFGetField(pTif, TIFFTAG_COMPRESSION, &nComp);
	nret = TIFFGetField(pTif, TIFFTAG_PHOTOMETRIC, &nPho);

	//������趨
	if (nret == 1)
		m_isWhiteSmall = nPho == 0;
	else
		m_isWhiteSmall = true;

	nret = TIFFGetField(pTif, TIFFTAG_BITSPERSAMPLE, &nBps);
	nret = TIFFGetField(pTif, TIFFTAG_SAMPLESPERPIXEL, &nSpp);
	//nret = TIFFGetField(pTif, TIFFTAG_ROWSPERSTRIP, &nrps);//ÿ��strip�м���

	m_bitCount = nBps * nSpp;
	npage = TIFFNumberOfDirectories(pTif);

	size_t nSize = TIFFStripSize(pTif);//�������ֽ��������һ���������ֽ����п��ܱ����ֵС
	int nStrip = TIFFNumberOfStrips(pTif); //������

	//uint32* bc; 
	//nret = TIFFGetField(pTif, TIFFTAG_STRIPBYTECOUNTS, &bc);

	int nwb = BytesPerRow();

	//��ֹ�ظ�����
	if (m_rawData != nullptr)
	{
		delete[]m_rawData; m_rawData = nullptr;
	}

	m_rawData = new unsigned char[nwb * m_rows];

	//uint32 stripsize = bc[0];

	////����1��TIFFWriteScanline��֧��ѹ������
	//nret = TIFFScanlineSize(pTif);

	//for (int row = 0; row < nh; row++)
	//	TIFFReadScanline(pTif, m_rawData + row * nret, row);

	//����2��
	size_t offset = 0;
	for (int i = 0; i < nStrip; i++)
	{
		offset += TIFFReadEncodedStrip(pTif, i, m_rawData + offset, nSize);
	}

	TIFFClose(pTif);
	return true;
}

bool TiffHelper::Save(const System::Char * file)
{
	return Save2File(m_rawData, m_cols, m_rows, m_bitCount, file, m_isWhiteSmall);
}

bool TiffHelper::IsWhiteSmall()
{
	return m_isWhiteSmall;
}

bool TiffHelper::Save2File(unsigned char* pBuf, int nW, int nH, int nBpp, const System::Char * file, bool isWhtieSmall, bool filpX, bool filpY)
{
	TIFF *pTif = TIFFOpenEx(file, "w");
	if (!pTif)
		return false;

	unsigned char* saveBuff = pBuf;

	int nwb = BYTESPERROW(nW, nBpp);

	TIFFSetField(pTif, TIFFTAG_IMAGEWIDTH, nW);
	TIFFSetField(pTif, TIFFTAG_IMAGELENGTH, nH);
	TIFFSetField(pTif, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB);
	TIFFSetField(pTif, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG); //single image plane
	TIFFSetField(pTif, TIFFTAG_XRESOLUTION, 72.0); // must be double
	TIFFSetField(pTif, TIFFTAG_YRESOLUTION, 72.0);
	TIFFSetField(pTif, TIFFTAG_RESOLUTIONUNIT, RESUNIT_INCH);
	TIFFSetField(pTif, TIFFTAG_IMAGEDESCRIPTION, "Kunshan Hisense Electronics Co.,Ltd.");//����

	TIFFSetField(pTif, TIFFTAG_COMPRESSION, COMPRESSION_LZW);//

	//int r = TIFFSetField(pTif, TIFFTAG_MAKE, "CJK");//���������
	//r = TIFFSetField(pTif, TIFFTAG_MODEL, "hs");//����ͺ�

	TIFFSetField(pTif, TIFFTAG_ARTIST, "Mr CJK");//����ͺ�
	//r = TIFFSetField(pTif, TIFFTAG_DATETIME, "2019:08:21 11:30:00");//c //YYYY:MM:DD HH:MM:SS", with hours like those on a 24-hour clock
	TIFFSetField(pTif, TIFFTAG_SOFTWARE, "TiffHelper");//����ͺ�
	TIFFSetField(pTif, TIFFTAG_COPYRIGHT, "Copyright (C) HS Electronics");//��Ȩ��Ϣ


	//�������ҷ�ת
	if (filpX || filpY)
		saveBuff = FlipImage(pBuf, nW, nH, nBpp, filpY, filpX);

	switch (nBpp)
	{
	case 1:
	case 2:
	case 4:
	case 8:
	{
		TIFFSetField(pTif, TIFFTAG_PHOTOMETRIC, isWhtieSmall ? PHOTOMETRIC_MINISWHITE : PHOTOMETRIC_MINISBLACK);
		TIFFSetField(pTif, TIFFTAG_BITSPERSAMPLE, nBpp);
		TIFFSetField(pTif, TIFFTAG_SAMPLESPERPIXEL, 1);

		TIFFSetField(pTif, TIFFTAG_ROWSPERSTRIP, nH);

		//for (int i = 0; i < nH; i++)
		//{
		//	TIFFWriteScanline(pTif, pBuf + nwb*i, i);
		//}
		TIFFWriteEncodedStrip(pTif, 0, saveBuff, nwb*nH);
	}
	break;
	case 24:
	case 32:
	{
		TIFFSetField(pTif, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_RGB);

		TIFFSetField(pTif, TIFFTAG_BITSPERSAMPLE, 8);
		TIFFSetField(pTif, TIFFTAG_SAMPLESPERPIXEL, nBpp / 8);

		TIFFSetField(pTif, TIFFTAG_ROWSPERSTRIP, nH);

		TIFFWriteEncodedStrip(pTif, 0, saveBuff, nwb*nH);
	}
	break;
	default:
		break;
	}

	TIFFClose(pTif);

	if (filpX || filpY)
		delete[] saveBuff;

	return true;
}

unsigned char* TiffHelper::FlipImage(unsigned char* pBuf, int nW, int nH, int nBpp, bool filpY, bool filpX)
{
	if (!(filpY || filpX))
		return nullptr;

	int nwb = BYTESPERROW(nW, nBpp);
	unsigned char* saveBuff = new unsigned char[nwb * nH];
	{
		if (nBpp < 8)
			::memset(saveBuff, 0, nwb * nH);

		if (filpY)//���ҷ�ת
		{
			unsigned char* srcRow, *destRow;
			for (int i = 0; i < nH; i++)
			{
				srcRow = filpX ? pBuf + (nH - i - 1) * nwb : pBuf + i * nwb;
				destRow = saveBuff + i * nwb;

				//ÿ�����ص�һ�����һ���ߵ�
				switch (nBpp)
				{
				case 1:
				case 2:
				case 4:
				{
					int pixPerByte = (8 / nBpp);//ÿ���ֽ����ظ���
					unsigned char val, contVal;
					int destByte, destBitNo, srcByte, srcBitNo;

					if (nBpp == 1)
						contVal = 0x01;
					else if (nBpp == 2)
						contVal = 0x03;
					else// if (nBpp == 4)
						contVal = 0x0f;

					for (int w = 0; w < nW; w++)
					{
						destByte = w / pixPerByte;
						destBitNo = (pixPerByte - 1) - w % pixPerByte;

						srcByte = (nW - w - 1) / pixPerByte;
						srcBitNo = (pixPerByte - 1) - (nW - w - 1) % pixPerByte;

						val = (srcRow[srcByte] >> (nBpp * srcBitNo)) & contVal;

						destRow[destByte] |= (val << (nBpp * destBitNo));
					}
				}
				case 8:
				case 24:
				case 32:
				{
					int bytesPerPixel = nBpp / 8;

					for (int w = 0; w < nW; w++)
						for (int k = 0; k < bytesPerPixel; k++)
							*(destRow + w * bytesPerPixel + k) = *(srcRow + (nW - w - 1)*bytesPerPixel + k);
				}
				default:
					break;
				}
			}
		}
		else
		{
			if (filpX)//���·�ת
				for (int i = 0; i < nH; i++)
					::memcpy(saveBuff + i * nwb, pBuf + (nH - i - 1) * nwb, nwb);
		}
	}	
	return saveBuff;
}
