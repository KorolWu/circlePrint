#pragma once


class Interlock
{
public:
	Interlock();
	~Interlock();

public:
	//��plAdd��ַ��ֵ������incrementֵ
	static long ExchangeAdd(long * volatile pldest, long increment);
	static long long ExchangeAdd64(long long * volatile pldest, long long increment);

	static long ExchangeVal(long * volatile pldest, long lvalue);
	static long long ExchangeVal64(long long * volatile pldest, long long lvalue);

	static void* ExchangePtr(void* volatile *  ppdest, void* pvValue);

	//* pldest�е�ֵ����lComparand����* pldest=lExchange��
	//����ֵ��*pldest�н���ǰ��ֵ
	static long CompareExchange(long * volatile pldest, long lExchange, long lComparand);

	static void* CompareExchangePtr(void* volatile * ppdest, void* pvExchange, void * pvComparand);
};

