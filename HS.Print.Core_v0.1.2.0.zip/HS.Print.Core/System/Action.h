#pragma once
#include "OAction.h"

typedef void (*Action)(void *);


