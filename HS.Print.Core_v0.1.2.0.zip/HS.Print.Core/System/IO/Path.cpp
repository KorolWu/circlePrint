#include "Path.h"

using namespace System;
using namespace System::IO;


static inline int LastIndexOf(const String& path, Char value1, Char value2)
{
	if (path.length() == 0)
	{
		return -1;
	}

	int startIndex =(int) path.length();
	while (--startIndex >= 0)
	{
		Char ch = path[startIndex];
		if (ch == value1 || ch == value2)
		{
			return startIndex;
		}
	}

	return -1;
}


String Path::LongPathPrefix = String(_T("\\\\?\\"));


Path::Path()
{
}


Path::~Path()
{
}


String Path::Combine(const String& path1, const String& path2)
{
	if (path2.length() == 0)
	{
		return path1;
	}
	if (path1.length() == 0)
	{
		return path2;
	}

	Char ch = path1[path1.length() - 1];
	if ((ch != DirectorySeparatorChar && (ch != AltDirectorySeparatorChar)))
	{
		return (path1 +
#ifdef WIN32
			DirectorySeparatorChar
#else
			AltDirectorySeparatorChar
#endif			
			+ path2);
	}

	return (path1 + path2);
}

String Path::GetExtension(const String& path)
{
	if (path.length() == 0)
	{
		return EMPTYSTRING;
	}

	int length =(int) path.length();
	int startIndex = length;
	while (--startIndex >= 0)
	{
		Char ch = path[startIndex];
		if (ch == _T('.'))
		{
			if (startIndex != (length - 1))
			{
				return path.substr(startIndex, length - startIndex);
			}
			return EMPTYSTRING;
		}
		if (((ch == DirectorySeparatorChar) || (ch == AltDirectorySeparatorChar)))
		{
			break;
		}
	}

	return EMPTYSTRING;
}

String Path::GetFileName(const String& path)
{
	int index = LastIndexOf(path, DirectorySeparatorChar, AltDirectorySeparatorChar);

	if (index < 0)
		return path;

	return path.substr(index + 1, (path.length() - index) - 1);
}

String Path::GetFileNameWithoutExtension(const String& path)
{
	if (path.length() == 0)
	{
		return EMPTYSTRING;
	}

	size_t length = path.length();
	int startIndex = (int)length;

	int exIndex = -1;//��չ������
	while (--startIndex >= 0)
	{
		Char ch = path[startIndex];
		if (ch == _T('.'))
		{
			if (exIndex < 0 )
			{
				if(startIndex != (length - 1))
					exIndex = startIndex;
				else
					break;//����ͷ����
			}
		}
		//�ж��Ƿ񵽴�Ŀ¼��б�߷ָ��
		if (((ch == DirectorySeparatorChar) || (ch == AltDirectorySeparatorChar)))
		{
			break;
		}
	}

	//����չ��
	if (exIndex == -1)
	{
		//��б�ߵ�·����Ϣ
		if(startIndex<0)
			return path;
		else
			return path.substr(startIndex + 1, path.length() - 1);
	}
	else
	{
		if(exIndex < startIndex)//˵���ҵ���.�Ų�����չ���ָ�����������չ��
			return path.substr(startIndex + 1, (path.length() - startIndex) - 1);
		else
			return path.substr(startIndex + 1, exIndex - startIndex - 1);
	}

}


String Path::GetDirectoryName(const String& folderPath)
{
	//��������б�߽�����ַ�������Ҫȥ��б��Ȼ���ȡ�ļ�����
	if (folderPath.length() <= 0)
		return folderPath;

	size_t len = folderPath.length();
	Char ch = folderPath[len - 1];

	if (((ch == DirectorySeparatorChar) || (ch == AltDirectorySeparatorChar)))
	{
		String src = folderPath.substr(0, len - 1);
		return	GetFileName(src);
	}
	else
	{
		return	GetFileName(folderPath);
	}
}

String Path::GetFormatDirectory(const String& path)
{
	if (path.length() <= 0)
		return path;

	int len = (int)path.length();
	Char ch = path[len - 1];

	if (((ch == DirectorySeparatorChar) || (ch == AltDirectorySeparatorChar)))
		return path.substr(0, len - 1);
	else
	{
		return path;
	}
}

String Path::GetFileDirectory(const String& filePath)
{
	if (filePath.length() <= 0)
		return filePath;

	size_t len = filePath.length();
	Char ch = filePath[len - 1];

	if (((ch == DirectorySeparatorChar) || (ch == AltDirectorySeparatorChar)))
		return filePath.substr(0, len - 1);
	else
	{
		len = LastIndexOf(filePath, DirectorySeparatorChar, AltDirectorySeparatorChar);
		return filePath.substr(0, len);
	}
}
