
#pragma once

#include "../String.h"
#include "../Object.h"

namespace System
{
	namespace Except
	{
		//�쳣�Ļ���
		class Exception : public System::Object
		{
		private:
			System::String m_msg;

		public:
			Exception():m_msg(_T("Exception"))
			{}

			Exception::Exception(const Char * msg)
			: m_msg(msg)
			{}


			virtual ~Exception(){}

		public:
			const System::Char * What() const
			{
				return m_msg.c_str();
			}



		};
	}
}

