#include "Encodor.h"
#include <clocale>
#include <cstdlib>

#if defined(WIN32) ||  defined(_WIN32)
#include <windows.h>
#endif

using namespace System::Text;

// wstring => string
std::string WString2String(const std::wstring& ws)
{
	std::string result;

#if defined( WIN32) ||  defined(_WIN32)
	//windows��Ϊ���ֽ���
	//��ʼת��
	Encodor::WCS2MBCS(ws.c_str(), result);
#else
	//linux��utf8
	Encodor::Unicode2UTF8(ws.c_str(), result);
#endif // WIN32) ||  defined(_WIN32)
	return result;
}

// string => wstring
std::wstring String2WString(const std::string& s)
{
	std::wstring wstrResult;

#if defined( WIN32) ||  defined(_WIN32)
	//windows��Ϊ���ֽ���
	//��ʼת��
	Encodor::MBCS2WCS(s.c_str(), wstrResult);
#else
	//linux��stringΪutf8
	Encodor::UTF82Unicode(s.c_str(), wstrResult);
#endif // WIN32) ||  defined(_WIN32)
	return wstrResult;
}

Encodor::Encodor()
{
}


Encodor::~Encodor()
{
}


size_t Encodor::Unicode2UTF8(unsigned int unic, unsigned char pOutput[UNICODE2UTF8MAXBYTES])
{
	size_t dec = 0;

	if (unic <= 0x0000007F)
		dec = 1;
	else if (unic >= 0x00000080 && unic <= 0x000007FF)
		dec = 2;
	else if (unic >= 0x00000800 && unic <= 0x0000FFFF)
		dec = 3;
	else if (unic >= 0x00010000 && unic <= 0x001FFFFF)
		dec = 4;
	else if (unic >= 0x00200000 && unic <= 0x03FFFFFF)
		dec = 5;
	else if (unic >= 0x04000000 && unic <= 0x7FFFFFFF)
		dec = 6;

	if (dec > 0 && pOutput != nullptr)
	{
		switch (dec)
		{
		case 1:
			// * U-00000000 - U-0000007F:  0xxxxxxx  
			*pOutput = (unic & 0x7F);
			break;
		case 2:
			// * U-00000080 - U-000007FF:  110xxxxx 10xxxxxx  
			*(pOutput + 1) = (unic & 0x3F) | 0x80;
			*pOutput = ((unic >> 6) & 0x1F) | 0xC0;
			break;
		case 3:
			// * U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx  
			*(pOutput + 2) = (unic & 0x3F) | 0x80;
			*(pOutput + 1) = ((unic >> 6) & 0x3F) | 0x80;
			*pOutput = ((unic >> 12) & 0x0F) | 0xE0;

			break;
		case 4:
			// * U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx  
			*(pOutput + 3) = (unic & 0x3F) | 0x80;
			*(pOutput + 2) = ((unic >> 6) & 0x3F) | 0x80;
			*(pOutput + 1) = ((unic >> 12) & 0x3F) | 0x80;
			*pOutput = ((unic >> 18) & 0x07) | 0xF0;

			break;
		case 5:
			// * U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx  
			*(pOutput + 4) = (unic & 0x3F) | 0x80;
			*(pOutput + 3) = ((unic >> 6) & 0x3F) | 0x80;
			*(pOutput + 2) = ((unic >> 12) & 0x3F) | 0x80;
			*(pOutput + 1) = ((unic >> 18) & 0x3F) | 0x80;
			*pOutput = ((unic >> 24) & 0x03) | 0xF8;
			break;
		case 6:
			// * U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx  
			*(pOutput + 5) = (unic & 0x3F) | 0x80;
			*(pOutput + 4) = ((unic >> 6) & 0x3F) | 0x80;
			*(pOutput + 3) = ((unic >> 12) & 0x3F) | 0x80;
			*(pOutput + 2) = ((unic >> 18) & 0x3F) | 0x80;
			*(pOutput + 1) = ((unic >> 24) & 0x3F) | 0x80;
			*pOutput = ((unic >> 30) & 0x01) | 0xFC;
			break;
		}
	}

	return dec;
}

size_t Encodor::UTF8ToUnicode(unsigned char* utf8, unsigned int* pOutput)
{
	if (utf8 == nullptr)
		return 0;

	size_t dec = 0;

	// 1* U-00000000 - U-0000007F:  0xxxxxxx  
	// 2* U-00000080 - U-000007FF:  110xxxxx 10xxxxxx  
	// 3* U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx  
	// 4* U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx  
	// 5* U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx  
	// 6* U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx  

	if (*utf8 <= 0x7F)
		dec = 1;
	else if (*utf8 <= 0xBF)	//���ѡ���λ��Ϊutf���10xxxxxx�򷵻�0
		return 0;
	else if (*utf8 <= 0xDF)
		dec = 2;
	else if (*utf8 <= 0xEF)
		dec = 3;
	else if (*utf8 <= 0xF7)
		dec = 4;
	else if (*utf8 <= 0xFB)
		dec = 5;
	else if (*utf8 <= 0xFD)
		dec = 6;

	if (dec > 0 && pOutput != nullptr)
	{
		switch (dec)
		{
		case 1:
			*pOutput = *utf8;
			break;
		case 2:
			*pOutput = ((utf8[0] & 0x1f) << 6) | (utf8[1] & 0x3f);
			break;
		case 3:
			*pOutput = ((utf8[0] & 0x0f) << 12) | ((utf8[1] & 0x3f) << 6) | (utf8[2] & 0x3f);
			break;
		case 4:
			*pOutput = ((utf8[0] & 0x07) << 18) | ((utf8[1] & 0x3f) << 12) | ((utf8[2] & 0x3f) << 6) | (utf8[3] & 0x3f);
			break;
		case 5:
			*pOutput = ((utf8[0] & 0x03) << 24) | ((utf8[1] & 0x3f) << 18) | ((utf8[2] & 0x3f) << 12) | ((utf8[3] & 0x3f) << 6) | (utf8[4] & 0x3f);
			break;
		case 6:
			*pOutput = ((utf8[0] & 0x01) << 30) | ((utf8[1] & 0x3f) << 24) | ((utf8[2] & 0x3f) << 18) | ((utf8[3] & 0x3f) << 12) | ((utf8[4] & 0x3f) << 6) | (utf8[5] & 0x3f);
			break;
		}
	}
	return dec;
}

size_t Encodor::Unicode2UTF8(const wchar_t * unicString, char * utf8String)
{
	if (unicString == nullptr)
		return 0;

	size_t totalChar = 0;
	size_t nChar = 0;
	char * tmp = utf8String;

	while (*unicString != L'\0')
	{
		nChar = Unicode2UTF8((unsigned int)(*unicString), (unsigned char*)tmp);

		//����
		if (nChar == 0)
		{
			totalChar = 0;
			break;
		}

		unicString++;
		totalChar += nChar;

		if (utf8String != nullptr)
			tmp += nChar;
	}

	if (utf8String != nullptr)
		*tmp = '\0';

	return totalChar + 1;
}

size_t Encodor::UTF8ToUnicode(const char * utf8Str, wchar_t * unicStr)
{
	if (utf8Str == nullptr)
		return 0;


	size_t totalChar = 0;
	size_t nChar = 0;
	unsigned int unic = 0;

	wchar_t * tmp = unicStr;
	while (*utf8Str != '\0')
	{
		nChar = UTF8ToUnicode((unsigned char*)utf8Str, &unic);
		if (nChar == 0)
		{
			//����д�������������ã���Ϊ0���ȣ�
			totalChar = 0; break;;
		}

		totalChar++;
		utf8Str += nChar;

		if (unicStr != nullptr)
			*tmp++ = (wchar_t)unic;
	}

	if (unicStr != nullptr)
		*tmp = L'\0';

	return totalChar + 1;
}

size_t Encodor::WCS2MBCS(const wchar_t * wsrc, char * result, size_t sizeInBytes)
{
	if (wsrc == nullptr)
		return 0;

#if defined(WIN32) ||  defined(_WIN32)

	sizeInBytes = ::WideCharToMultiByte(CP_ACP, 0, wsrc, -1, result, (int)(result == nullptr ? 0 : sizeInBytes), 0, 0);

#else
	char *  strLocale = setlocale(LC_ALL, "");
	//��ʼת��
	wcstombs_s(&sizeInBytes, result, result == nullptr ? 0 : sizeInBytes, wsrc, _TRUNCATE);
	setlocale(LC_ALL, strLocale);
#endif

	return sizeInBytes;
}

size_t Encodor::MBCS2WCS(const char * src, wchar_t* wstrResult, size_t sizeInWords)
{
	if (src == nullptr)
		return 0;

#if defined(WIN32) ||  defined(_WIN32)

	sizeInWords = ::MultiByteToWideChar(CP_ACP, 0, src, -1, wstrResult, (int)(wstrResult == nullptr ? 0 : sizeInWords));

#else
	char *  strLocale = setlocale(LC_ALL, "");
	//��ʼת��
	mbstowcs_s(&sizeInWords, wstrResult, wstrResult == nullptr ? 0 : sizeInWords, src, _TRUNCATE);
	setlocale(LC_ALL, strLocale);
#endif

	return sizeInWords;
}


