#pragma once
#include "../System/Object.h"

class PrinterBoard;
class SpittingHelper : public System::Object
{
private:
	volatile bool m_needSpitting;

	unsigned int m_freq;
	int m_openTime;
	int m_closeTime;

	void * m_taskHandle;
	void * m_mutexHandle;

	PrinterBoard & m_printBoard;
public:
	SpittingHelper(PrinterBoard & printBoard);
	~SpittingHelper();

private:

	void SpittingTask(void *);

public:
	//��ʼ����
	int StartSpitting(unsigned int freq, int openTime, int closeTime);
	//ֹͣ����
	int StopSpitting();
	//�Ƿ���������
	bool IsInSpitting() const;
};

