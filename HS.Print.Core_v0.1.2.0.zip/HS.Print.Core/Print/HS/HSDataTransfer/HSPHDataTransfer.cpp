
#include <cstring>
#include "HSPHDataTransfer.h"
#include "../../../ErrMacro.h"
#include "Data.h"

#define HOST2NET(x)  (( x<<24 )| ((x & 0xff00)<<8)  | (x>>24) | ((x>>8)  & 0xff00))
#define BYTESPERROW1(nw, nBpp) ((nw * nBpp) >> 3) + ((nw * nBpp) % 8 == 0 ? 0 : 1)  

HSPHDataTransfer::HSPHDataTransfer(PHType type, int port, int nozNum)
	: m_phType(type)
	, m_phPort(port)
	, m_nozNum(nozNum)
	, m_encoderRes(0.5)
	, m_yDPI(100)
{
}

HSPHDataTransfer::~HSPHDataTransfer()
{
}

int HSPHDataTransfer::GetRawSwatheLen(int height) const
{
	//���ݳ��ȣ��ֽڣ�=16��Э��ͷ�� +  64*ͼ��߶�
	return PROHEADLEN + ONEPASSLINELEN * height;
}

int HSPHDataTransfer::ProtcolHeadLen() const
{
	return PROHEADLEN;
}


int HSPHDataTransfer::PassLinedLen() const
{
	return ONEPASSLINELEN;
}

//����passͷ����
int HSPHDataTransfer::SetPassHeadParam(unsigned int misDist, int height, unsigned char* param) const
{
	unsigned int interval = (unsigned int)(25400 / (m_yDPI * m_encoderRes));
	unsigned int curPassSize = 32 * height;//32Ϊ�������ֵ��Ӧ��Ϊ64�����������ݶ��岻�淶

	*((unsigned int *)param) = 0;
	param += 4;

	*((unsigned int *)param) = HOST2NET(misDist);
	param += 4;

	*((unsigned int *)param) = HOST2NET(interval);
	param += 4;

	*((unsigned int *)param) = HOST2NET(curPassSize);

	return ERR_PB_NOERR;
}

int HSPHDataTransfer::FillRawSwathe(const SwatheInfo * swathe, unsigned char * rawbuff, int totalLen)
{
	//��˹��ͷֻ�ܴ�����ɫλͼ
	int ret;
	unsigned char * bufRow;
	unsigned char * swRow;
	int nozInByte = 0;
	int nozInIndex = 0;
	int rowBytes = BYTESPERROW1(swathe->Width, swathe->BitsPerPixel);

	::memset(rawbuff, 0, totalLen);

	for (int h = 0; h < swathe->Height; h++)
	{
		//pass������
		bufRow = rawbuff + h * PassLinedLen();
		swRow = swathe->Data + h * rowBytes;

		for (int noz = 0; noz < m_nozNum; noz++)
		{
			if (!IsBlackDot(swRow, swathe->BitsPerPixel, noz))
				continue;

			ret = nozInByte = GetBytesPosWhenPrint(noz, &nozInIndex);

			if (ret < 0)//��ֹ����
				return ret;

			bufRow[nozInByte] |= (0x01 << nozInIndex);
		}
	}

	return ERR_PB_NOERR;
}

bool HSPHDataTransfer::IsBlackDot(const unsigned char * swRow, unsigned char nbb, int x)
{
	if (nbb == 8)//SwatheInfo��dataΪ8bit
		return swRow[x] < 128;//����
	else//
		return swRow[x] < 128;
}

void HSPHDataTransfer::SetPrintCfg(float encoderRes, float yDpi)
{
	m_encoderRes = encoderRes;
	m_yDPI = yDpi;
}

int HSPHDataTransfer::GenRawSwathe(const SwatheInfo * swathe, unsigned int misEncoderPlsNum, unsigned char ** data, int *num)
{
	if (swathe == nullptr)
		return ERR_PB_INPUTERR;

	//��������Ƿ�ƥ��
	if (swathe->PHType != m_phType)
		return ERR_PB_SWATHEPHERR;

	//�������Ƿ�һ��
	if (swathe->Width != m_nozNum)
		return ERR_PB_SWATHEWIDTHERR;

	int ret;
	//���ݳ��ȣ��ֽڣ�=16��Э��ͷ�� +  64*ͼ��߶�
	int len = GetRawSwatheLen(swathe->Height);
	//buff
	unsigned char *tmp = new unsigned char[len];

	//���ݷ�װ
	if (ERR_PB_NOERR != (ret = SetPassHeadParam(misEncoderPlsNum, swathe->Height, tmp)))
		goto LabErr;

	if (ERR_PB_NOERR != (ret = FillRawSwathe(swathe, tmp + PROHEADLEN, len - PROHEADLEN)))
		goto LabErr;

	*data = tmp;
	*num = len;

	return ERR_PB_NOERR;

LabErr:
	delete[] tmp;
	return ret;
}

int HSPHDataTransfer::TransferNozOpen(unsigned char *arrNozz, int bytes, unsigned int ** data, int *num)
{
	if (arrNozz == nullptr || bytes == 0)
		return ERR_PB_INPUTERR;
	//
	unsigned char * tmp = new unsigned char[ONEPASSLINELEN];
	::memset(tmp, 0, ONEPASSLINELEN);

	int ret;
	int nozInByte = 0;
	int nozInIndex = 0;

	for (int i = 0; i < bytes; i++)
	{
		for (int bit = 7; bit >= 0; bit--)
		{
			//�Ƿ���Ҫ����
			if (((arrNozz[i] >> bit) & 0x01) == 1)
			{
				//noz = (8 * i + (7 - bit));
				ret = nozInByte = GetBytesPosWhenTest((8 * i + (7 - bit)), &nozInIndex);

				if (ret < 0)//��ֹ����
					return ret;

				tmp[nozInByte] |= (0x01 << nozInIndex);
			}
		}
	}

	*data = (unsigned int *)tmp;
	*num = 16;// ONEPASSLINELEN / 4;

	return ERR_PB_NOERR;
}
