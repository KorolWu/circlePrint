#include "../../ErrMacro.h"

#include "HSDataTransfer/SE128PHDataTransfer.h"
#include "HSDataTransfer/QS256PHDataTransfer.h"
#include "HSDataTransfer/DMC160PHDataTransfer.h"
#include "HSPBDataGenerator.h"


int HSPBDataGenerator::CreatePHDataTransfer(int port, PHType type, IPHDataTransfer * & tfer)
{
	switch (type)
	{
	case PHTSE128:
		tfer = new SE128PHDataTransfer(port);
		return ERR_PB_NOERR;
	case PHTQS256:
		tfer = new QS256PHDataTransfer(port);
		return ERR_PB_NOERR;
	case PHDMC116:
		tfer = new DMC160PHDataTransfer(port);
		return ERR_PB_NOERR;
	}

	return ERR_PB_INVALDPHTYPE;
}
