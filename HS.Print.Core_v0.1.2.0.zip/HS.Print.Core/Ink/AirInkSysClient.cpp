#include "../stdafx.h"
#include "../Utils/Tools/Mutex.h"
#include "../Utils/Ports/SerialPort/SerialPort.h"
#include "../ErrMacro.h"
#include "InkCmd.h"
#include "AirInkSysClient.h"

#define m_mutex ((Utils::Tools::Mutex*)m_mutexHd)
#define RETRYTIME 10


//CRC У������� C ���Գ���ʾ����
//data ��ҪУ�����ʼ����ָ��
//length ��ҪУ�����������
static unsigned short CalCRC(unsigned char* data, int length)
{
	int j;
	unsigned short reg_crc = 0xFFFF;
	while (length--)
	{
		reg_crc ^= *data++;
		for (j = 0; j < 8; j++)
		{
			if (reg_crc & 0x01)
				reg_crc = (reg_crc >> 1) ^ 0xA001;
			else
				reg_crc = reg_crc >> 1;
		}
	}
	return reg_crc;// ����CRCУ����
}


AirInkSysClient::AirInkSysClient()
	: m_mutexHd(new Utils::Tools::Mutex)
	, m_serPort(nullptr)
	, m_isOpen(false)
{
	m_nSendTimeout = 1000;//ms
	m_nRecvTimeout = 500;//ms

	m_serPort = new SerialPort;
}


AirInkSysClient::~AirInkSysClient()
{
	//�ȹر�
	Close();
	m_mutex->UnLock();
	delete m_mutex; m_mutexHd = nullptr;
	delete m_serPort; m_serPort = nullptr;
	m_isOpen = false;
}


int AirInkSysClient::Open(const System::Char * portName)
{
	if (m_serPort == nullptr)
		return ERR_PB_DISCON;

	m_mutex->Lock();
	m_isOpen = false;

	LONG lLastError = m_serPort->Open(portName, 0, 0, true);
	if (lLastError != ERROR_SUCCESS)
		goto LabEnd;


	// Setup the serial port (9600,N81) using hardware handshaking
	lLastError = m_serPort->Setup(SerialPort::EBaud19200, SerialPort::EData8, SerialPort::EParNone, SerialPort::EStop1);
	if (lLastError != ERROR_SUCCESS)
		goto LabEnd;

	//// Setup handshaking
	//lLastError = m_serPort->SetupHandshaking(SerialPort::EHandshakeHardware);
	//if (lLastError != ERROR_SUCCESS)
	//	goto LabEnd;


	lLastError = m_serPort->SetupReadTimeouts(SerialPort::EReadTimeoutNonblocking);
	if (lLastError != ERROR_SUCCESS)
		goto LabEnd;


	lLastError = m_serPort->SetMask(SerialPort::EEventBreak |
		SerialPort::EEventError |
		SerialPort::EEventRecv |
		SerialPort::EEventCTS |
		SerialPort::EEventDSR |
		SerialPort::EEventSend);
	if (lLastError != ERROR_SUCCESS)
		goto LabEnd;


	m_isOpen = true;
	m_mutex->UnLock();


	return ERR_PB_NOERR;

LabEnd:
	m_serPort->Close();
	m_mutex->UnLock();

	return (int)lLastError;
}

void AirInkSysClient::Close()
{
	m_mutex->Lock();
	m_isOpen = false;

	//����ر�
	if (m_serPort != nullptr)
		m_serPort->Close();

	m_mutex->UnLock();
}

bool AirInkSysClient::IsConnected()
{
	return m_isOpen && m_serPort != nullptr && m_serPort->IsOpen();
}

int AirInkSysClient::SendAndRecv(const unsigned char* sndData, int sndLen, unsigned char * ack, int ackLen)
{
	if (!m_isOpen)
		return ERR_PB_DISCON;

	if (sndLen == 0 || ackLen == 0)
		return ERR_PB_INPUTERR;

	DWORD readNum = 0;
	LONG res;
	m_mutex->Lock();

	//���ж�һ�Σ���ֹ�˿ڹر��˶���������
	if (!m_isOpen)
	{
		res = ERR_PB_DISCON;
		goto labErr;
	}
	//�����������
	m_serPort->Purge();
	//д��
	res = m_serPort->Write(sndData, sndLen);
	if (res != ERROR_SUCCESS)
		goto labErr;

	//�ȴ��ײ���յ�������
	Sleep(20);

	//ѭ����ȡ
	int val = RETRYTIME;//���10��
	sndLen = 0;//��Ϊ��ʱ����ʹ��

	while (true)
	{
		res = m_serPort->Read(ack + sndLen, ackLen - sndLen, &readNum);
		if (res != ERROR_SUCCESS)
			goto labErr;

		sndLen += readNum;
		//�Ƿ�ﵽָ������
		if (sndLen >= ackLen)
			break;
		else
			Sleep(10);

		if (val-- <= 0)
		{
			res = ERR_PB_ERRACKLEN;
			goto labErr;
		}
	}

	m_mutex->UnLock();

	return ERR_PB_NOERR;

labErr:
	m_mutex->UnLock();
	return (int)res;
}


int AirInkSysClient::DataOP(unsigned char* sndData, int sndLen, unsigned char * ack, int ackLen, bool checkFK)
{
	int res = ERROR_SUCCESS;
	unsigned short crc;
	sndData[0] = CMDHEAD;

	crc = CalCRC(sndData, sndLen - CRCLEN);

	sndData[sndLen - 2] = (crc >> 8) & 0xff;
	sndData[sndLen - 1] = crc & 0xff;

	res = SendAndRecv(sndData, sndLen, ack, ackLen);
	if (ERROR_SUCCESS != res)
		return res;

	//���ݷ���
	//����ͷ��֤
	if (ack[0] != ACKHEAD)
		return ERR_PB_ERRHEAD;

	//CRCУ��
	crc = (unsigned short)(ack[ackLen - 1] | (ack[ackLen - 2] << 8));

	if (crc != CalCRC(ack, ackLen - CRCLEN))
		return ERR_PB_INVALIDCRC;

	//2.���鹦�ܺ�
	if (ack[1] != sndData[1])
		return ERR_PB_FUNCNO;

	//3.���鷴��ֵ
	if (checkFK)
		if (ack[2] != 0x00)
			return ERR_PB_SETFAILED;

	return ERR_PB_NOERR;
}


int AirInkSysClient::SetVacuum(bool isOpen, unsigned short range)
{
	if (range > 4095)
		range = 4095;

	byte buff[BASICLEN] = { 0 };
	byte ack[BASICLEN] = { 0 };

	buff[1] = SETVACUMME;

	buff[2] = isOpen ? 1 : 0;
	buff[3] = (range >> 8) & 0xff;
	buff[4] = range & 0xff;;

	return DataOP(buff, BASICLEN, ack, BASICLEN);
}

int AirInkSysClient::SetPressure(float meniscus, float extrudeInk)
{
	if (meniscus < 0 || meniscus > 5 || extrudeInk < 0 || extrudeInk > 50)
		return ERR_PB_INPUTERR;


	byte buff[BASICLEN] = { 0 };
	byte ack[BASICLEN] = { 0 };

	buff[1] = SETPREESSURE;

	unsigned short tmp;

	tmp = (unsigned short)(meniscus * 942.0 + 100);
	buff[2] = (tmp >> 8) & 0xff;
	buff[3] = tmp & 0xff;


	tmp = (unsigned short)(extrudeInk * 3150 / 48.1 + 409);
	buff[4] = (tmp >> 8) & 0xff;
	buff[5] = tmp & 0xff;


	return DataOP(buff, BASICLEN, ack, BASICLEN);
}

int AirInkSysClient::ExtrudeInkOnce()
{
	byte buff[BASICLEN] = { 0 };
	byte ack[BASICLEN] = { 0 };

	buff[1] = EXTRUDEDINK;

	return DataOP(buff, BASICLEN, ack, BASICLEN);
}

int AirInkSysClient::QueryCfgParams(float *meniscus, float* extrudeInk, unsigned short *vacRange)
{
	if (meniscus == nullptr || extrudeInk == nullptr || vacRange == nullptr)
		return ERR_PB_INPUTERR;

	unsigned short tmp;
	byte buff[BASICLEN] = { 0 };
	byte ack[QUERYACKLEN] = { 0 };

	buff[1] = QUERYREALVAL;

	int res = DataOP(buff, BASICLEN, ack, QUERYACKLEN, false);

	if (ERR_PB_NOERR != res)
		return res;

	//������������
	tmp = (unsigned short)(ack[3] | (ack[2] << 8));
	*meniscus = (float)((tmp - 100) / 942.0);

	tmp = (unsigned short)(ack[5] | (ack[4] << 8));
	*extrudeInk = (float)((tmp - 409) * 48.1 / 3150.0);

	*vacRange = (unsigned short)((ack[6] << 8) | ack[7]);

	return ERR_PB_NOERR;
}

int AirInkSysClient::QueryVersion(int *major, int *minor)
{
	if (major == nullptr || minor == nullptr)
		return ERR_PB_INPUTERR;

	byte buff[BASICLEN] = { 0 };
	byte ack[BASICLEN] = { 0 };

	buff[1] = GETVERSION;

	int res = DataOP(buff, BASICLEN, ack, BASICLEN, false);

	if (ERR_PB_NOERR != res)
		return res;

	//������������
	*major = ack[2];
	*minor = ack[3];

	return ERR_PB_NOERR;
}

