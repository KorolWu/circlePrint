// dllmain.cpp : ���� DLL Ӧ�ó������ڵ㡣
#include "stdafx.h"
#include "Winsock2.h"
#include "Model/SystemDataHelper.h"

#define SOCKMAINVER 2
#define SOCKMINORVER 2

#pragma comment(lib,"ws2_32.lib")

BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH://�����̹���ʱ������socket����
	{
		WSADATA wsd;
		if (0 != WSAStartup(MAKEWORD(SOCKMAINVER, SOCKMINORVER), &wsd))
			return FALSE;
		//����Ƿ�����汾Ҫ��
		//The high-order byte specifies the minor version number; 
		//the low-order byte specifies the major version number
		if (LOBYTE(wsd.wVersion) != SOCKMAINVER || HIBYTE(wsd.wVersion) != SOCKMINORVER)
			return FALSE;

		//��ʼ��ȫ������
		if (!SystemDataHelper::OnAllConfigOK())
			return FALSE;

	}
	break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
	{
		WSACleanup();
		SystemDataHelper::DeleteInstance();
	}
	break;
	}
	return TRUE;
}

