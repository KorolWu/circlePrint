// HS.Print.Core.cpp : ���� DLL Ӧ�ó���ĵ���������
//
#include "stdafx.h"
#include "HS.Print.Core.h"
#include "ErrMacro.h"
#include "Model/SystemDataHelper.h"
#include "Print/HS/HSPBDataGenerator.h"
#include "Model/ImageSplitHelper.h"
#include "Model/FileDecoder.h"


#define printerBoard SystemDataHelper::GetPrinterBoard()
#define inkSysClient SystemDataHelper::GetAirInkSysClient()

const Char * HSFNTYPE Ink_Print_GetErrInfo(int errCode)
{
	if (errCode)
		return _T("����0��ϵͳ������");

	switch (errCode)
	{
	case ERR_PB_NOERR:
		return _T("�޴���");
	case ERR_PB_DISCON:
		return _T("ͨѶδ����");
	case ERR_PB_TIMEOUT:
		return _T("ͨѶ��ʱ");
	case ERR_PB_FUNCNO:
		return _T("������������벻һ��");
	case ERR_PB_INPUTERR:
		return _T("�����������");

	case ERR_PB_CMDACKMTERR:
		return _T("�����뷴��ֵƥ��ʧ��");

	case ERR_PB_INVALIDCRC:
		return _T("CRCУ��ʧ��");

	case ERR_PB_SETFAILED:
		return _T("���ò���ʧ��");
	case ERR_PB_ERRHEAD:
		return _T("��Ч������ͷ");
	case ERR_PB_ERRACKLEN:
		return _T("�������ݲ�����");


	case ERR_PB_RAWPASSERR:  return _T("�·���RawSwathe���ϴ������ݶԱȲ�һ��");
	case ERR_PB_INVALDPHTYPE:  return _T("��Ч����ͷ����");
	case ERR_PB_INVALDPHPORT: return _T("��Ч����ͷ�˿�");
	case ERR_PB_SWATHEPHERR: return _T("Swathe��ͷ������DataTransfer���Ͳ�һ��");
	case ERR_PB_SWATHEWIDTHERR: return _T("Swathe������DataTransfer����ͷ������һ��");
	case ERR_PB_UNSUPPORT: return _T("��֧�ֵ���ͷ�˿ں�");

	case ERR_PB_FILENOTEXIST: return _T("ָ��·�����ļ�������");
	case ERR_PB_INVALIDFILENAME:  return _T("ָ��·�����ļ�����Ч");
	case ERR_PB_UNSUPIMGFORMAT:  return _T("ͼ�θ�ʽ��֧��");
	case ERR_PB_LOADFILEFAILED:  return _T("ͼ������ʧ��");
	case ERR_PB_DELFILEFAILED:  return _T("ͼ��ɾ��ʧ��");


	case ERR_PB_CREATESPITTHREAD:  return _T("���������߳�ʧ��");
	case ERR_PB_SPITTHREADABORT:  return _T("�����߳���ֹ");

	default:
	case ERR_PB_UNKONWN: return _T("����/δ֪����");
	}
}


/*************************** ͼ�μ��� ****************************/

int HSFNTYPE GenSwatheInfoFromFile(const Char * file, const SwatheSplitCfg * cfg, PrintInfo ** printInfo)
{
	int res;
	ImageData data;
	FileDecoder dec(file);

	if ((res = dec.CheckFileValidate()) != ERR_PB_NOERR)
		return res;

	::memset(&data, 0, sizeof(ImageData));
	//��ȡ�ļ�
	if ((res = dec.GetImageData(data)) != ERR_PB_NOERR)
		return res;

	return GenSwatheInfoFromBuff(&data, cfg, printInfo);
}

int HSFNTYPE GenSwatheInfoFromBuff(const ImageData * data, const SwatheSplitCfg * cfg, PrintInfo ** printInfo)
{
	if (data == nullptr || cfg == nullptr)
		return ERR_PB_INPUTERR;

	int res;
	ImageSplitHelper hlp;

	if ((res = hlp.SetSplitCfg(cfg)) != ERR_PB_NOERR)
		return res;

	return hlp.SplitIntoSwatheInfoSet(data, printInfo);
}

HSPRINTAPI void HSFNTYPE DeletePrintInfo(PrintInfo ** printInfo)
{
	if (*printInfo == nullptr)
		return;

	for (int i = 0; i < (*printInfo)->SwatheCount; i++)
	{
		delete[](*printInfo)->SwatheInfoSet[i]->Data;
		delete (*printInfo)->SwatheInfoSet[i]; (*printInfo)->SwatheInfoSet[i] = nullptr;
	}

	delete[](*printInfo)->SwatheInfoSet;

	delete (*printInfo); *printInfo = nullptr;
}

/*************************** ��ӡ��� ****************************/


int HSFNTYPE Print_Connect(unsigned int IPAddress, unsigned short PortNum)
{
	return printerBoard.Connect(IPAddress, PortNum);
}

HSPRINTAPI int HSFNTYPE Print_PreInit()
{
	//���������Դ
	int res = printerBoard.PowerInit();

	if (res != ERR_PB_NOERR)
		return res;
	//Ҫ�ȴ�һ��
	Sleep(500);

	return ERR_PB_NOERR;
}


int HSFNTYPE Print_Init(PHType type)
{
	if (type > PHTDMC11610)
		return ERR_PB_INVALDPHTYPE;

	//������ͷ����
	int res = Print_SetPHType(type);

	if (res != ERR_PB_NOERR)
		return res;

	//����Ĭ�ϲ����ļ�
	WaveformInfo waveform = { 2, 6, 2, 30, WFChnAddr1 };
	int freq = 2000;

	switch (type)
	{
	case PHTSE128:
	{
		waveform.Vol = 90;
	}
	break;
	case PHTQS256:
	{
		waveform.Vol = 70;
	}
	break;
	case PHDMC116:
	{
		waveform.Due = 12;
		waveform.Vol = 40;
	}
	break;
	case PHUnknown:
	default:
		return ERR_PB_INVALDPHTYPE;
	}


	for (int i = 0; i < 2; i++)
	{
		waveform.ChnAddr = (i == 0) ? WFChnAddr1 : WFChnAddr2;

		res = Print_SetWaveform(&waveform);
		if (res != ERR_PB_NOERR)
			return res;
	}

	return printerBoard.SetFireFrequency(freq);
}

void HSFNTYPE Print_Disconnect()
{
	printerBoard.Disconnect();
}

int HSFNTYPE Print_SetFireFreq(unsigned int uFireFreq)
{
	return printerBoard.SetFireFrequency(uFireFreq);
}

int HSFNTYPE Print_SetWaveform(const WaveformInfo * waveform)
{
	if (waveform == nullptr)
		return ERR_PB_INPUTERR;

	return printerBoard.SendWaveForm(waveform->Rise, waveform->Fall,
		waveform->Due, waveform->Vol,
		waveform->ChnAddr);
}


HSPRINTAPI int HSFNTYPE Print_SetPrintCfg(PrintCfg * cfg)
{
	if (cfg == nullptr)
		return ERR_PB_INPUTERR;

	//��¼��ǰ������ֵ
	SystemDataHelper::UpdatePrintCfg(cfg);

	return ERR_PB_NOERR;
}

int HSFNTYPE Print_SetPHType(PHType type)
{
	int res = printerBoard.SetPrintHeadType(type);

	//�����͸��µ�ȫ��
	if (res == ERR_PB_NOERR)
		SystemDataHelper::UpdatePHType(type);

	return res;
}

PHType HSFNTYPE Print_GetSelPHType()
{
	return SystemDataHelper::GetPHType();
}

#ifdef _DEBUG
void SaveBuff(unsigned char *pass, int size)
{

	FILE * file = fopen("D:\\310pass.txt", "wb");
	int sur = size % 16;
	int num = size / 16 + (sur == 0 ? 0 : 1);

	unsigned char *tmp = pass;

	for (int i = 0; i < num; i++)
	{

		fwrite(tmp, i + 1 == num ? sur : 16, 1, file);

		tmp += 16;
	}

	fflush(file);
	fclose(file);
}
#endif

int HSFNTYPE Print_DownloadSwathe(int port, const SwatheInfo * swathe, int checkErr)
{
	return Print_DownloadSwatheEx(port, swathe, checkErr, 0);
}

int HSFNTYPE Print_DownloadSwatheEx(int port, const SwatheInfo * swathe, int checkErr, int ignorePlsNum)
{
	//���ݲ�ͬ���͵���ͷ����ͼƬ��������
	int res;
	int num = 0;
	byte* data = nullptr;
	PHType type = PHUnknown;
	IPHDataTransfer *gen = nullptr;
	const PrintCfg & cfg = SystemDataHelper::GetPrintCfg();

	if (swathe == nullptr)
		return ERR_PB_INPUTERR;

	type = swathe->PHType;
	if (type > PHTDMC11610)
		return ERR_PB_INVALDPHTYPE;

	res = HSPBDataGenerator::CreatePHDataTransfer(port, type, gen);

	if (res != ERR_PB_NOERR)
		return res;
	//���÷ֱ��ʺ�DPI
	gen->SetPrintCfg(cfg.EncoderRes, cfg.RequiredDPI);
	//��ȡRaw����
	res = gen->GenRawSwathe(swathe, ignorePlsNum, &data, &num);
	//������ϣ����
	delete gen;
	if (res != ERR_PB_NOERR)
		return res;

#ifdef _DEBUG
	SaveBuff(data, num);
#endif
	//�·�
	res = printerBoard.SendOnePassData(data, num, (checkErr != 0));

	if (res == ERR_PB_RAWPASSERR)//���Pass��һ�¾��ط�һ��
		res = printerBoard.SendOnePassData(data, num, (checkErr != 0));
	if (res != ERR_PB_NOERR)
		goto labErr;


	delete[]data;
	return ERR_PB_NOERR;

labErr:
	delete[]data;
	return res;
}

int HSFNTYPE Print_EnterPrintMode()
{
	return printerBoard.StartPrint();
}

int HSFNTYPE Print_ExitPrintMode()
{
	return printerBoard.StopPrint();
}

int HSFNTYPE Print_StartSpitting(unsigned int freq, int openTime, int closeTime)
{
	SpittingHelper & spitHlp = SystemDataHelper::GetSpittingHelper();
	return	spitHlp.StartSpitting(freq, openTime, closeTime);
}

int HSFNTYPE Print_StopSpitting()
{
	SpittingHelper & spitHlp = SystemDataHelper::GetSpittingHelper();
	return	spitHlp.StopSpitting();
}

int HSFNTYPE Print_SetTestNoz(int isOn)
{
	return printerBoard.NozzleTestControl(isOn == 0 ? false : true);
}

int HSFNTYPE Print_SetLampCurrent(unsigned short current)
{
	return printerBoard.TuneLEDCurrent(current);
}

int HSFNTYPE Print_SetLampPhase(unsigned int lum)
{
	return printerBoard.TuneLEDLum(lum);
}

int HSFNTYPE Print_SetNozOpen(int port, unsigned char *arrNozz, int bytes)
{
	//����������
	int res;
	int num = 0;
	uint32* data = nullptr;
	PHType type = SystemDataHelper::GetPHType();

	if (arrNozz == nullptr)
		return ERR_PB_INPUTERR;

	if (type > PHTDMC11610)
		return ERR_PB_INVALDPHTYPE;

	//������Ҫ�೤������
	IPHDataTransfer *gen = nullptr;
	res = HSPBDataGenerator::CreatePHDataTransfer(port, type, gen);

	if (res != ERR_PB_NOERR)
		return res;

	res = gen->TransferNozOpen(arrNozz, bytes, &data, &num);
	//������ϣ����
	delete gen;

	if (res != ERR_PB_NOERR)
	{
		if (data != nullptr)
			delete[] data;
		return res;
	}

	res = printerBoard.SetNozzleData(data, num);//����512��ͷ����

	delete[] data;

	return res;
}

int HSFNTYPE Print_SetFlyMode(int isOn)
{
	return printerBoard.SlowMode(isOn == 0 ? false : true);
}

int HSFNTYPE Print_SetFlySpeed(unsigned char speed)
{
	return printerBoard.TuneDelaySpeed(speed);
}

/*************************** ��ī·��� ****************************/


int HSFNTYPE AirInk_Open(const Char * portName)
{
	return inkSysClient.Open(portName);
}

void HSFNTYPE AirInk_Close()
{
	inkSysClient.Close();
}

int HSFNTYPE AirInk_IsConnected()
{
	return	inkSysClient.IsConnected() ? 1 : 0;
}

int HSFNTYPE AirInk_SetVacuum(int isOpen, unsigned short range)
{
	return inkSysClient.SetVacuum(isOpen != 0, range);
}

int HSFNTYPE AirInk_SetPressure(float meniscus, float extrudeInk)
{
	return inkSysClient.SetPressure(meniscus, extrudeInk);
}

int HSFNTYPE AirInk_ExtrudeInkOnce()
{
	return inkSysClient.ExtrudeInkOnce();
}

int HSFNTYPE AirInk_GetCfgParams(float *meniscus, float* extrudeInk, unsigned short *vacRange)
{
	return inkSysClient.QueryCfgParams(meniscus, extrudeInk, vacRange);
}

int HSFNTYPE AirInk_GetVersion(int *major, int *minor)
{
	return inkSysClient.QueryVersion(major, minor);
}

