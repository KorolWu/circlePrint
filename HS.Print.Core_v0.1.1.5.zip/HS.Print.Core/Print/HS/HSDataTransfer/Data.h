#pragma once

#define ONEPASSLINELEN    64 
#define PROHEADLEN        16
