#include <cstring>
#include "DMC160PHDataTransfer.h"

DMC160PHDataTransfer::DMC160PHDataTransfer(int port)
	:HSPHDataTransfer(PHDMC116, port, 16)
{
}

DMC160PHDataTransfer::~DMC160PHDataTransfer()
{
}

int DMC160PHDataTransfer::GetBytesPosWhenPrint(int nozIndex, int *index)
{
	if (m_phPort != 0)
		return ERR_PB_UNSUPPORT;

	*index = nozIndex % 8;
	return (nozIndex > 7) ? 58 : 59;//64Ϊ֡����ONEPASSLINELEN
}

int DMC160PHDataTransfer::GetBytesPosWhenTest(int nozIndex, int *index)
{
	if (m_phPort == 0)
	{
		*index = nozIndex % 8;
		return (nozIndex > 7) ? 5 : 4;//64Ϊ֡����ONEPASSLINELEN
	}
	else if (m_phPort == 1)
	{
		*index = nozIndex % 8;
		return (nozIndex > 7) ? 37 : 36;//64Ϊ֡����ONEPASSLINELEN
	}

	return ERR_PB_UNSUPPORT;
}

