#pragma once

#include"../String.h"

namespace System
{
	namespace IO
	{
		using namespace System;

		class File
		{
		private:
			File();
			~File();

		public:

			static bool Delete(const String& path);

			static bool Exists(const String& path);

		};
	}
}