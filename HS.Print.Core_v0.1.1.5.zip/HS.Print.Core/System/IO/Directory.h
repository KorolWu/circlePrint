#pragma once

#include"../String.h"
//#include <Array>

namespace System
{
	namespace IO
	{
		using namespace System;

		class Directory
		{
		private:
			Directory();
			~Directory();

		private:
			static int GetSelectedFileSyetemInfo(const String& path, const String& pattern, int option, String *&files);
		public:
			static bool Create(const String& path);
			//ɾ��һ���հ�Ŀ¼
			static bool Delete(const String& path);
			//static void Delete(String path, bool recursive);
			static bool Exists(const String& path);

			//��ȡĿ¼�µ�������Ϣ
			static int GetFileSyetemInfo(const String&  path, String *&files);
			//��ȡĿ�µ��ļ���Ϣ
			static int GetFiles(const String&  path, String *&files);

			static int GetFiles(const String&  path, const String&  pattern, String *&files);

			//��ȡĿ¼�µ���Ŀ¼��Ŀ¼���Ϊ0����Ϣ
			static int GetDirectories(const String&  path, String *&files);
			static int GetDirectories(const String& path, const String&  pattern, String *&files);

		};
	}
}