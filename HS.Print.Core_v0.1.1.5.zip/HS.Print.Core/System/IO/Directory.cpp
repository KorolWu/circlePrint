
//���ΪUnicode�Ͳ�����ִ��
//#if !defined(UNICODE) && !defined(_UNICODE) 

#include "Directory.h"
#include "Path.h"
#include <list>


//�����ļ����ļ��е�����ͨ�������Ե�Flag���л����������յ�attribֵ
#define ReadOnlyFlag  1
#define HidenFlag  2

#define NormalDirectory 16
#define NormalFile 32

#if  defined( WIN32)|| defined(_WIN32)

#include <direct.h>  
#include <io.h>
#include<wchar.h>

#define MAX_PATH          260

//�ɹ�����0�����򷵻�-1
//ʹ��rmdir����ʱ��Ŀ¼����Ϊ�գ��������ʧ��

#if defined(UNICODE) || defined(_UNICODE) 

#define ACCESS  _waccess
#define MKDIR(x)  _wmkdir(x) 
#define RMDIR(x)  _wrmdir(x) 

#else
#define ACCESS  _access
#define MKDIR(x)  _mkdir(x) 
#define RMDIR(x)  _rmdir(x) 
#endif //UNICODE

#define IsDir(attrib) (((attrib>>4) & 1) > 0)

#else
#include <dirent.h>  
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>

#define MAX_PATH         4096

//0755Ȩ�޴����ļ���
#define MKDIR(x) mkdir(x,S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH) 
//ʹ��rmdir����ʱ��Ŀ¼����Ϊ�գ��������ʧ��
#define RMDIR(x) rmdir(x) 

#define ACCESS access

#error Directory.cpp�ж��ڷ�WIN32ƽ̨�µ�IsDirδʵ��. 
#endif //WIN32

#define SHOWFULLPATH(val) (((val>>3) & 1) > 0)
#define ONLYSHOWFILE(val) ((val & 1) > 0)
#define ONLYSHOWDIR(val) (((val>>1) & 1) > 0)


#define _A_NORMAL       0x00    /* Normal file - No read/write restrictions */
#define _A_RDONLY       0x01    /* Read only file */
#define _A_HIDDEN       0x02    /* Hidden file */
#define _A_SYSTEM       0x04    /* System file */
#define _A_SUBDIR       0x10    /* Subdirectory */
#define _A_ARCH         0x20    /* Archive file */



using namespace System::IO;
using namespace System;


//��ȡɸѡ���ļ�ϵͳ��Ϣ
//option 1ֻɸѡ�ļ���Ϣ��2ֻɸѡĿ¼��Ϣ,������������,����λ��ʾ�Ƿ�Ҫ���ȫ·��
int Directory::GetSelectedFileSyetemInfo(const String& path, const String& pattern, int option, String *&files)
{
	_finddata_t file_info;

	String format = Path::Combine(path, pattern);

	intptr_t handle = _findfirst(NEWSTR2CHARSTR(format).c_str(), &file_info);

	if (-1 == handle)
		return 0;

	std::list <String> lst;

	do
	{
		//�Ƿ�Ϊ��Ч���ļ�ϵͳ����������ʾ��..��.��
		if(strcmp(file_info.name, ".") == 0 || strcmp(file_info.name, "..") == 0)
			continue;

		if (ONLYSHOWFILE(option))//Ϊ�ļ���Ϣ
		{
			if (IsDir(file_info.attrib))
				continue;
		}

		if (ONLYSHOWDIR(option))//ΪĿ¼��Ϣ
		{
			if (!IsDir(file_info.attrib))
				continue;
		}

		lst.push_back(SHOWFULLPATH(option) ? Path::Combine(path, String(CHARSTR2NEWSTR(file_info.name))) : String(CHARSTR2NEWSTR(file_info.name)));
	} while (-1 != _findnext(handle, &file_info));

	_findclose(handle);

	size_t count = lst.size();
	if (count > 0)
	{
		files = new String[count];
		int i = 0;

		for (std::list<String>::iterator val = lst.begin(); val != lst.end(); val++)
		{
			files[i++] = *val;
		}
		return (int)count;
	}

	return 0;
}



Directory::Directory()
{
}


Directory::~Directory()
{


}

int CreateDir(const Char* pathName)  
{  
	Char dirName[MAX_PATH];
	Strcpy_s(dirName, MAX_PATH, pathName);

	size_t len = Strlen(pathName);
	if(pathName[len-1]!= _T('/') && pathName[len-1]!= _T('\\'))  
	{
		Strcat_s(dirName, MAX_PATH, _T( "/"));
		len +=1;
	}

	for(size_t i=1; i< len;   i++)
	{  
		if(dirName[i]==_T('/')|| dirName[i]==_T('\\'))  
		{  
			dirName[i] =  0;  

			//PathFileExists

#if  defined( WIN32)|| defined(_WIN32) || (!defined(UNICODE) && ! defined(_UNICODE))

			if(ACCESS(dirName,00)!=0   )  
			{  
				if(MKDIR(dirName)==-1)  
					return   -1;   
			}  
#else
			if(ACCESS(NEWSTR2CHARSTR(String(dirName)).c_str(),00) !=0  )  
			{  
				if(MKDIR(NEWSTR2CHARSTR(String(dirName)).c_str())==-1)  
					return   -1;   
			}  
#endif //WIN32 !UNICODE
			dirName[i] =_T('/');  
		}  
	}  
	return   0;  
} 

bool Directory::Create(const String& path)
{
	return CreateDir(path.c_str()) == 0;
}

bool Directory::Delete(const String& path)
{
#if  defined( WIN32)|| defined(_WIN32)
	return	RMDIR(path.c_str()) == 0;
#else
	return	RMDIR(NEWSTR2CHARSTR(path).c_str()) == 0;
#endif
}

//void Directory::Delete(String path, bool recursive)
//{
//
//}

bool Directory::Exists(const String& path)
{
	//���庬�����£�
	//	R_OK ֻ�ж��Ƿ��ж�Ȩ��
	//	W_OK ֻ�ж��Ƿ���дȨ��
	//	X_OK �ж��Ƿ���ִ��Ȩ��
	//	F_OK ֻ�ж��Ƿ����
	//	�ں궨������ֱ��Ӧ��
	//	00 ֻ����
	//	02 дȨ��
	//	04 ��Ȩ��
	//	06 ����дȨ��
#if  defined( WIN32)|| defined(_WIN32)
	return	ACCESS(path.c_str(),00) == 0;
#else
	return ACCESS(NEWSTR2CHARSTR(Path::GetFormatDirectory(path)).c_str(), 00) !=-1;
#endif

	/*_finddata_t file_info;

		intptr_t handle = _findfirst(NEWSTR2CHARSTR(Path::GetFormatDirectory(path)).c_str(), &file_info);

		if (-1 == handle)
			return false;

		_findclose(handle);

	return true;*/
}


int Directory::GetFileSyetemInfo(const String&  path, String *&files)
{
	return GetSelectedFileSyetemInfo(path, _T("*.*"), 4 | 1 << 3, files);
}


int Directory::GetFiles(const String& path, String *&files)
{
	return GetSelectedFileSyetemInfo(path, _T("*.*"), 1 | 1 << 3, files);
}

int Directory::GetFiles(const String&  path, const String&  pattern, String *&files)
{
	return GetSelectedFileSyetemInfo(path, pattern, 1 | 1 << 3, files);
}

int Directory::GetDirectories(const String& path, String *&files)
{
	return GetSelectedFileSyetemInfo(path, _T("*.*"), 2 | 1 << 3, files);
}

int Directory::GetDirectories(const String& path, const String&  pattern, String *&files)
{
	return GetSelectedFileSyetemInfo(path, pattern, 2 | 1 << 3, files);
}


//#endif //UNICODE
