#ifndef _BITMAPTYPEDEF_H_
#define  _BITMAPTYPEDEF_H_


#pragma once


#if defined(WIN32) || defined(_WIN32)

#include <windows.h>

#if defined(_MSC_VER) 
#if _MSC_VER < 1600
#define nullptr NULL
#endif
#endif 

#else

/* constants for the biCompression field */
#define BI_RGB        0L
#define BI_RLE8       1L
#define BI_RLE4       2L
#define BI_BITFIELDS  3L
#define BI_JPEG       4L
#define BI_PNG        5L

typedef unsigned char BYTE;//һ���ֽ�
typedef long long LONGLONG;//8���ֽ�
typedef unsigned long       DWORD;//4���ֽ�
typedef unsigned short      WORD;//2���ֽ�
typedef int LONG;//4���ֽڣ�����Ϊint����Ҫ��Ϊ�˿�ƽ̨��linux64��long����Ϊ8�ֽڣ���win64�µ�4�ֽڲ�ͬ
				 //�ļ�ͷ
typedef struct tagBITMAPFILEHEADER {
	WORD    bfType;
	DWORD   bfSize;
	WORD    bfReserved1;
	WORD    bfReserved2;
	DWORD   bfOffBits;
} BITMAPFILEHEADER;
//�ļ���Ϣͷ
typedef struct tagBITMAPINFOHEADER {
	//BITMAPINFOHEADER���ֽ���
	DWORD      biSize;
	LONG       biWidth;
	LONG       biHeight;
	WORD       biPlanes;
	WORD       biBitCount;
	DWORD      biCompression;
	//ͼ��ʵ��ռ�õ��ֽ���
	DWORD      biSizeImage;
	LONG       biXPelsPerMeter;
	LONG       biYPelsPerMeter;
	DWORD      biClrUsed;
	DWORD      biClrImportant;
} BITMAPINFOHEADER;

typedef struct tagBITMAPV4HEADER {
	DWORD        bV4Size;
	LONG         bV4Width;
	LONG         bV4Height;
	WORD         bV4Planes;
	WORD         bV4BitCount;
	DWORD        bV4V4Compression;
	DWORD        bV4SizeImage;
	LONG         bV4XPelsPerMeter;
	LONG         bV4YPelsPerMeter;
	DWORD        bV4ClrUsed;
	DWORD        bV4ClrImportant;
	DWORD        bV4RedMask;
	DWORD        bV4GreenMask;
	DWORD        bV4BlueMask;
	DWORD        bV4AlphaMask;
	DWORD        bV4CSType;
	CIEXYZTRIPLE bV4Endpoints;
	DWORD        bV4GammaRed;
	DWORD        bV4GammaGreen;
	DWORD        bV4GammaBlue;
} BITMAPV4HEADER;

typedef struct tagBITMAPV5HEADER {
	DWORD        bV5Size;
	LONG         bV5Width;
	LONG         bV5Height;
	WORD         bV5Planes;
	WORD         bV5BitCount;
	DWORD        bV5Compression;
	DWORD        bV5SizeImage;
	LONG         bV5XPelsPerMeter;
	LONG         bV5YPelsPerMeter;
	DWORD        bV5ClrUsed;
	DWORD        bV5ClrImportant;
	DWORD        bV5RedMask;
	DWORD        bV5GreenMask;
	DWORD        bV5BlueMask;
	DWORD        bV5AlphaMask;
	DWORD        bV5CSType;
	CIEXYZTRIPLE bV5Endpoints;
	DWORD        bV5GammaRed;
	DWORD        bV5GammaGreen;
	DWORD        bV5GammaBlue;
	DWORD        bV5Intent;
	DWORD        bV5ProfileData;
	DWORD        bV5ProfileSize;
	DWORD        bV5Reserved;
} BITMAPV5HEADER;
//��ɫ��
typedef struct tagRGBQUAD {
	BYTE    rgbBlue;
	BYTE    rgbGreen;
	BYTE    rgbRed;
	BYTE    rgbReserved;
} RGBQUAD;

typedef struct tagBITMAPINFO {
	BITMAPINFOHEADER    bmiHeader;
	RGBQUAD             bmiColors[1];
} BITMAPINFO;

#endif //WIN32

#endif //_BITMAPTYPEDEF_H_
