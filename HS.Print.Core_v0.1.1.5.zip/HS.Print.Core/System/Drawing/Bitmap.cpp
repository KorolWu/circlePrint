
#include<cstdio>
#include <memory.h>

#include "Bitmap.h"

using namespace std;
using namespace System;
using namespace System::Drawing;


#if defined(UNICODE) || defined(_UNICODE) 
#define Fopen_s _wfopen_s //��ռ��ʽ��
#define Fsopen _wfsopen //������ʽ��
#else
#define Fopen_s fopen_s
#define Fsopen _fsopen
#endif

Bitmap::Bitmap()
	:m_bitMapData(nullptr),
	m_pInfoHead(nullptr),
	m_bitMapDataLen(0)
{
}

Bitmap::Bitmap(byte * bitMapData, longlong dataLen)
	:m_bitMapData(bitMapData),
	m_pInfoHead((BITMAPINFOHEADER *)m_bitMapData),
	m_bitMapDataLen(bitMapData == nullptr ? 0 : dataLen)
{

}

Bitmap::Bitmap(const Bitmap & map)
{
	if (map.m_bitMapData == nullptr || map.m_bitMapDataLen == 0)
	{
		m_bitMapData = nullptr;
		m_pInfoHead = nullptr;
		m_bitMapDataLen = 0;
		return;
	}

	m_bitMapData = new byte[(uint32)map.m_bitMapDataLen];
	//��ͼƬ�������ݸ���һ��
	memcpy_s(m_bitMapData, (size_t)map.m_bitMapDataLen, map.m_bitMapData, (size_t)map.m_bitMapDataLen);
	m_pInfoHead = (BITMAPINFOHEADER *)m_bitMapData;
	m_bitMapDataLen = map.m_bitMapDataLen;
}

Bitmap::~Bitmap(void)
{
	Dispose();
}

byte * Bitmap::FromFile(const String& filename, longlong* datasSze)
{
	/*�ַ��� ����

	"r" ��ֻ����ʽ���ļ�

	"w" ��ֻд��ʽ���ļ�

	"a" ��׷�ӷ�ʽ���ļ�

	"r+" �Զ� / д��ʽ���ļ��������ļ�����

	"w+" �Զ� / д��ʽ���ļ��������ļ��������ļ�*/

	FILE * file = nullptr;

	Fopen_s(&file, filename.c_str(), _T("rb"));


	if (file == nullptr)
	{
		return nullptr;
	}

	BITMAPFILEHEADER head;
	//����ļ�ͷ�����Ƿ���ȷ
	if (fread(&head, sizeof(BITMAPFILEHEADER), 1, file) != 1)
		goto labErr;

	//����ļ�����
	if (head.bfType != 0x4D42)
		goto labErr;

	// ƫ�Ƶ��ļ�β��
	fseek(file, 0, SEEK_END);
	int32 pos = (int32)ftell(file);//��ȡβ������λ��

	if (pos != head.bfSize)
		goto labErr;


	*datasSze = head.bfSize - sizeof(BITMAPFILEHEADER);

	byte * buffer = new byte[(uint32)*datasSze];

	if (buffer == nullptr)
	{
		goto labErr;
	}

	//�ƶ��α�ͷ
	fseek(file, sizeof(head), SEEK_SET);

	size_t num = fread(buffer, 1,(size_t) *datasSze, file);

	//	size_t num = 0;
	//#define READBUFFERSIZE 2048
	//	//�ֶλ�ȡ����
	//	do
	//	{
	//		num += fread(buffer + num, 1, READBUFFERSIZE, file);
	//		//�����ȡ�����ݳ����Ѿ��㹻���˳�ѭ��
	//		//����ֹ�ļ��������úͻ��峤��һ��������ѭ������ʱnumΪ�ļ����ȣ�feof����ļ�δ�������´���freadʱ����ֵΪ0��
	//		if (num >= (size_t)*datasSze)
	//			break;
	//	} while (!feof(file));
	//
	//#undef  READBUFFERSIZE

	fclose(file);

	BITMAPINFOHEADER* headInfo = (BITMAPINFOHEADER*)buffer;

	//���������ֵ�Ĵ�����Ϊ��ֵ����Ҫ��
	if (headInfo->biSizeImage == 0)
		headInfo->biSizeImage = ((((headInfo->biWidth * headInfo->biBitCount) + 31) >> 5) << 2) * headInfo->biHeight;

	return buffer;

labErr:
	*datasSze = 0;
	fclose(file);
	return nullptr;

}

bool Bitmap::Save(byte * bgr24, longlong bgr24Len, BITMAPINFOHEADER * info, const String& filename)
{
	FILE * file = nullptr;

	Fopen_s(&file, filename.c_str(), _T("wb+"));

	if (file == nullptr)
	{
		return false;
	}

	//�����ļ�ͷ 
	BITMAPFILEHEADER head;
	head.bfType = 0x4D42;//'M''B'
	head.bfSize = (DWORD)(bgr24Len + sizeof(head) + sizeof(BITMAPINFOHEADER));
	head.bfReserved1 = 0;
	head.bfReserved2 = 0;
	head.bfOffBits = head.bfSize - info->biSizeImage;

	size_t num = 0;

	do
	{
		//�ȴ洢�ļ�ͷ
		num += fwrite((byte *)&head + num, 1, sizeof(head) - num, file);
	} while (num < sizeof(head));

	//�ƶ��ļ�ָ��
	fseek(file, sizeof(head), SEEK_SET);

	num = 0;
	do
	{
		//�ȴ洢�ļ�ͷ
		num += fwrite((byte *)info + num, 1, sizeof(BITMAPINFOHEADER) - num, file);
	} while (num < sizeof(head));

	//�ƶ��ļ�ָ��
	fseek(file, sizeof(head) + sizeof(BITMAPINFOHEADER), SEEK_SET);


	num = 0;
	do
	{
		num += fwrite((byte *)bgr24 + num, 1, (size_t)(bgr24Len - num), file);
	} while (num < (size_t)bgr24Len);


	fclose(file);

	return true;
}

bool Bitmap::Save(byte * hDIB, longlong dataLen, const String& filename)
{
	FILE * file = nullptr;

	Fopen_s(&file, filename.c_str(), _T("wb+"));

	if (file == nullptr)
	{
		return false;
	}


	BITMAPINFOHEADER *info = (BITMAPINFOHEADER*)hDIB;

	//�����ļ�ͷ 
	BITMAPFILEHEADER head;
	head.bfType = 0x4D42;//'M''B'
	head.bfSize = (DWORD)(dataLen + sizeof(head));
	head.bfReserved1 = 0;
	head.bfReserved2 = 0;
	head.bfOffBits = head.bfSize - info->biSizeImage;

	size_t num = 0;

	do
	{
		//�ȴ洢�ļ�ͷ
		num += fwrite((byte *)&head + num, 1, sizeof(head) - num, file);
	} while (num < sizeof(head));

	//�ƶ��ļ�ָ��
	fseek(file, sizeof(head), SEEK_SET);

	num = 0;
	do
	{
		num += fwrite((byte *)hDIB + num, 1, (size_t)(dataLen - num), file);
	} while (num < (size_t)dataLen);


	fclose(file);

	return true;
}


Bitmap* Bitmap::FromFile(const String& filename)
{
	longlong size = 0;
	byte * buffer = FromFile(filename, &size);

	if (buffer != nullptr)
		return new Bitmap(buffer, size);
	else
		return nullptr;
}

void Bitmap::Dispose(Bitmap * hDIB)
{
	if (hDIB != nullptr)
		delete hDIB;
}

void Bitmap::Dispose(byte * hDIB)
{
	if (hDIB != nullptr)
		delete[] hDIB;
}

bool Bitmap::LoadFromFile(const String& filename)
{
	//���ͷ�֮ǰ������
	Dispose();

	//��ȡͼƬ����
	m_bitMapData = FromFile(filename, &m_bitMapDataLen);
	//��ȡ��Ϣͷ
	m_pInfoHead = (BITMAPINFOHEADER *)m_bitMapData;

	return m_bitMapData != nullptr;
}

void Bitmap::Dispose()
{
	if (m_bitMapData != nullptr)
	{
		delete[] m_bitMapData;
		m_bitMapData = nullptr;
		m_pInfoHead = nullptr;
		m_bitMapDataLen = 0;
	}
}


//byte *  Bitmap::GetAllData()
//{
//	return m_bitMapData;
//}

//byte * Bitmap::GetRawData()
//{
//	if (m_bitMapData != nullptr)
//		return m_bitMapData + m_bitMapDataLen - m_pInfoHead->biSizeImage;
//	else
//		return nullptr;
//}



//int32  Bitmap::Height() const
//{
//	if (m_pInfoHead != nullptr)
//		return m_pInfoHead->biHeight;
//
//	return 0;
//}

////����px
// int32  Bitmap::Width() const
//{
//	if (m_pInfoHead != nullptr)
//		return m_pInfoHead->biWidth;
//
//	return 0;
//}

////ÿ��ռ�õ��ֽ���
//int32  Bitmap::GetWidthBytes() const
//{
//	if (m_pInfoHead != nullptr)
//		return	 ((m_pInfoHead->biWidth * m_pInfoHead->biBitCount) + 31) / 32 * 4;
//
//	return 0;
//}

//int32 Bitmap::GetBitCount() const
//{
//	if (m_pInfoHead != nullptr)
//		return	 m_pInfoHead->biBitCount;
//
//	return 0;
//}


ColorPalette Bitmap::GetPalette()
{
	//8λ�������µ�ͼ���е�ɫ��
	if (m_pInfoHead != nullptr && m_pInfoHead->biBitCount<=8)
	{
		int32 count = (int32)((m_bitMapDataLen - m_pInfoHead->biSize - m_pInfoHead->biSizeImage) / sizeof(RGBQUAD));
		return ColorPalette(count == 0 ? nullptr : ((byte *)m_pInfoHead + m_pInfoHead->biSize), count);
	}
	
	return ColorPalette(nullptr, 0);
}


Bitmap& Bitmap::operator=(Bitmap& map)
{
	if (this == &map)
	{
		return *this;
	}

	this->Dispose();

	//����������
	m_bitMapData = new byte[(uint32)map.m_bitMapDataLen];

	memcpy_s(m_bitMapData, (size_t)map.m_bitMapDataLen, map.m_bitMapData, (size_t)map.m_bitMapDataLen);
	m_pInfoHead = (BITMAPINFOHEADER *)m_bitMapData;
	m_bitMapDataLen = map.m_bitMapDataLen;

	return *this;
}
